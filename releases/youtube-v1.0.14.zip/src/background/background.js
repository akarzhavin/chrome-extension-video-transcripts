//#region ../../packages/shared/src/analytics.ts
var e = [
	"extension_installed",
	"extension_updated",
	"onboarding_shown",
	"languages_configured",
	"subtitles_loaded",
	"dual_subs_shown",
	"no_subtitles",
	"subs_partial",
	"subs_rate_limited",
	"subs_recovered",
	"word_save_attempt",
	"word_saved",
	"signin_started",
	"analytics_opt_out",
	"retained_d2",
	"retained_d7",
	"retained_d14"
], t = 18, n = 40, r = 100, i = [
	"uid",
	"user_id",
	"userid",
	"email",
	"id_token",
	"refresh_token",
	"term",
	"context",
	"text",
	"url",
	"video_id",
	"video_ref",
	"title"
];
function a(e = {}) {
	let a = {}, o = 0;
	for (let [s, c] of Object.entries(e)) {
		if (c == null || typeof c != "string" && typeof c != "number" && typeof c != "boolean" || typeof c == "number" && !Number.isFinite(c) || i.includes(s.toLowerCase())) continue;
		if (o >= t) break;
		let e = s.slice(0, n);
		e in a || (a[e] = typeof c == "string" ? c.slice(0, r) : c, o++);
	}
	return a;
}
function o(e, t, n) {
	let r = {
		...a(t),
		session_id: n.sessionId,
		engagement_time_msec: 1,
		ext_source: n.extSource,
		ext_version: n.extVersion,
		ext_env: n.extEnv
	};
	return typeof n.daysSinceInstall == "number" && (r.days_since_install = n.daysSinceInstall), n.backend && (r.backend = n.backend), {
		client_id: n.clientId,
		non_personalized_ads: !0,
		events: [{
			name: e,
			params: r
		}]
	};
}
function s() {
	try {
		return typeof chrome > "u" || !chrome.runtime || chrome.runtime.id === "lingogram-embed" || typeof chrome.runtime.getManifest != "function";
	} catch {
		return !0;
	}
}
//#endregion
//#region ../../packages/shared/src/prefs.ts
var c = "prefs.v1";
//#endregion
//#region ../../packages/shared/src/SidebarUI.ts
function l(e) {
	return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${e}</svg>`;
}
l("<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z\"/>"), l("<path d=\"M15 18l-6-6 6-6\"/>"), l("<path d=\"M4 6h16M4 12h16M4 18h10\"/>"), l("<path d=\"M2 6s3-2 10-2 10 2 10 2v12s-3-2-10-2-10 2-10 2z\" opacity=\".4\"/><path d=\"M12 4v14\"/>"), l("<path d=\"M4 7V5h16v2M9 19h6M12 5v14\"/>"), l("<path d=\"M6 9l6 6 6-6\"/>"), l("<path d=\"M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z\"/>"), l("<path d=\"M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z\"/>"), l("<path d=\"M7 16V4m0 0L3 8m4-4l4 4M17 8v12m0 0l4-4m-4 4l-4-4\"/>"), l("<rect x=\"3\" y=\"9\" width=\"18\" height=\"6\" rx=\"1.5\"/>"), l("<rect x=\"3\" y=\"5\" width=\"18\" height=\"6\" rx=\"1.5\"/><rect x=\"3\" y=\"13.5\" width=\"18\" height=\"6\" rx=\"1.5\"/>"), l("<rect x=\"3\" y=\"5\" width=\"18\" height=\"6\" rx=\"1.5\"/><circle cx=\"6.5\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"17.5\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/>"), l("<rect x=\"2\" y=\"4\" width=\"20\" height=\"14\" rx=\"2\"/><path d=\"M6 14.5h12\"/>"), l("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 17h8\"/>"), l("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 13h8\"/>"), l("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 9h8\"/>");
//#endregion
//#region ../../packages/shared/src/auth/config.ts
var u = {
	env: "prod",
	projectId: "lingogram-prod",
	apiKey: "AIzaSyCHQt2zwkO-x8qm7wM5IwWAWrl_n8mlQLI",
	identityToolkitUrl: "https://identitytoolkit.googleapis.com",
	secureTokenUrl: "https://securetoken.googleapis.com",
	firestoreUrl: "https://firestore.googleapis.com",
	frontendBaseUrl: "https://lingogram.ai",
	source: "youtube-extension"
};
u.env;
//#endregion
//#region ../../packages/shared/src/auth/storage.ts
var d = {
	idToken: "auth.idToken",
	refreshToken: "auth.refreshToken",
	expiresAt: "auth.expiresAt",
	email: "auth.email",
	uid: "auth.uid",
	inboxCount: "inbox.count",
	savedWordCount: "rate.savedWordCount",
	ratePromptShown: "rate.promptShown"
}, f = {
	clientId: "analytics.clientId",
	installedAt: "analytics.installedAt",
	d2Sent: "analytics.d2Sent",
	d7Sent: "analytics.d7Sent",
	d14Sent: "analytics.d14Sent"
}, p = {
	sessionId: "analytics.sessionId",
	sessionAt: "analytics.sessionAt"
};
async function m() {
	let e = await chrome.storage.local.get([
		d.idToken,
		d.refreshToken,
		d.expiresAt,
		d.email,
		d.uid
	]), t = e[d.idToken], n = e[d.uid];
	return !t || !n ? null : {
		idToken: String(t),
		refreshToken: String(e[d.refreshToken] ?? ""),
		expiresAt: Number(e[d.expiresAt] ?? 0),
		email: String(e[d.email] ?? ""),
		uid: String(n)
	};
}
async function h(e) {
	await chrome.storage.local.set({
		[d.idToken]: e.idToken,
		[d.refreshToken]: e.refreshToken,
		[d.expiresAt]: e.expiresAt,
		[d.email]: e.email,
		[d.uid]: e.uid
	});
}
async function g() {
	await chrome.storage.local.remove([
		d.idToken,
		d.refreshToken,
		d.expiresAt,
		d.email,
		d.uid
	]);
}
async function _() {
	return (await chrome.storage.local.get(d.inboxCount))[d.inboxCount] ?? 0;
}
async function ee() {
	let e = await _() + 1;
	return await chrome.storage.local.set({ [d.inboxCount]: e }), e;
}
async function v() {
	return (await chrome.storage.local.get(d.savedWordCount))[d.savedWordCount] ?? 0;
}
async function y() {
	let e = await v() + 1;
	return await chrome.storage.local.set({ [d.savedWordCount]: e }), e;
}
async function te() {
	return (await chrome.storage.local.get(d.ratePromptShown))[d.ratePromptShown] === !0;
}
async function ne() {
	await chrome.storage.local.set({ [d.ratePromptShown]: !0 });
}
var re = 600 * 1e3, b = {
	value: "auth.pendingNonce",
	issuedAt: "auth.pendingNonceAt"
};
async function ie(e) {
	await chrome.storage.session.set({
		[b.value]: e,
		[b.issuedAt]: Date.now()
	});
}
async function x(e) {
	let t = await chrome.storage.session.get([b.value, b.issuedAt]), n = t[b.value], r = t[b.issuedAt], i = typeof n == "string" ? n : "", a = typeof r == "number" ? r : 0;
	return !i || !e || Date.now() - a > re ? !1 : i === e;
}
async function S() {
	await chrome.storage.session.remove([b.value, b.issuedAt]);
}
//#endregion
//#region ../../packages/shared/src/auth/firebaseRest.ts
function C(e) {
	let t = parseInt(e, 10);
	return Date.now() + t * 1e3;
}
async function w(e, t) {
	let n = `${e.secureTokenUrl}/v1/token?key=${encodeURIComponent(e.apiKey)}`, r = `grant_type=refresh_token&refresh_token=${encodeURIComponent(t)}`, i = await fetch(n, {
		method: "POST",
		headers: { "Content-Type": "application/x-www-form-urlencoded" },
		body: r
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.id_token,
		refreshToken: a.refresh_token,
		expiresAt: C(a.expires_in),
		uid: a.user_id
	};
}
async function T(e, t, n) {
	let r = `${e.identityToolkitUrl}/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(e.apiKey)}`, i = await fetch(r, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			token: t,
			returnSecureToken: !0
		})
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.idToken,
		refreshToken: a.refreshToken,
		expiresAt: C(a.expiresIn),
		uid: a.localId || n
	};
}
//#endregion
//#region ../../packages/shared/src/auth/firestoreRest.ts
var E = 500, D = 256, O = 2048, ae = 2e3, oe = 6e4;
async function k(e) {
	let t = await m();
	if (!t) throw Error("Not signed in");
	if (t.expiresAt > Date.now() + oe) return t;
	let n = await w(e, t.refreshToken), r = {
		...t,
		...n
	};
	return await h(r), r;
}
function A() {
	let e = /* @__PURE__ */ new Date();
	return e.getUTCFullYear() * 1e4 + (e.getUTCMonth() + 1) * 100 + e.getUTCDate();
}
var j = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
function M() {
	let e = new Uint8Array(20);
	crypto.getRandomValues(e);
	let t = "";
	for (let n = 0; n < 20; n++) t += j[e[n] % 62];
	return t;
}
function N(e, t) {
	return `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents/inbox/${encodeURIComponent(t)}`;
}
async function P(e, t, n) {
	let r = await fetch(N(e, n), { headers: { Authorization: `Bearer ${t}` } });
	if (r.status === 404) return null;
	if (r.status === 401) throw Error("Firestore sentinel 401");
	if (!r.ok) {
		let e = await r.text().catch(() => "");
		throw Error(`Firestore GET sentinel ${r.status}: ${e || r.statusText}`);
	}
	let i = (await r.json()).fields ?? {};
	return {
		dailyCount: parseInt(i.dailyCount?.integerValue ?? "0", 10),
		dayBucket: parseInt(i.dayBucket?.integerValue ?? "0", 10)
	};
}
function F(e, t, n, r) {
	let i = A(), a = r && r.dayBucket === i ? r.dailyCount + 1 : 1;
	if (a > E) throw Error(`Daily limit of ${E} words reached. Try again tomorrow.`);
	let o = M(), s = `projects/${e.projectId}/databases/(default)/documents/inbox/${t}`, c = `${s}/words/${o}`, l = {
		term: { stringValue: n.term },
		source: { stringValue: e.source },
		processed: { booleanValue: !1 }
	};
	return n.context && (l.context = { stringValue: n.context }), {
		writes: [{
			update: {
				name: c,
				fields: l
			},
			currentDocument: { exists: !1 },
			updateTransforms: [{
				fieldPath: "addedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}, {
			update: {
				name: s,
				fields: {
					dailyCount: { integerValue: String(a) },
					dayBucket: { integerValue: String(i) }
				}
			},
			updateTransforms: [{
				fieldPath: "lastAddedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}],
		wordId: o,
		documentPath: c
	};
}
function I(e) {
	return new TextEncoder().encode(e).length;
}
function L(e, t) {
	let n = new TextEncoder();
	if (n.encode(e).length <= t) return e;
	let r = 0, i = e.length;
	for (; r < i;) {
		let a = r + i + 1 >>> 1;
		n.encode(e.slice(0, a)).length <= t ? r = a : i = a - 1;
	}
	for (; r > 0;) {
		let t = e.charCodeAt(r - 1);
		if (t >= 55296 && t <= 56319) r--;
		else break;
	}
	return e.slice(0, r);
}
async function R(e, t) {
	let n = L(t.text.trim(), ae);
	if (!n) throw Error("empty feedback");
	let r = "", i = "";
	try {
		let t = await k(e);
		r = t.uid, i = t.idToken;
	} catch {}
	let a = String(A()), o = `projects/${e.projectId}/databases/(default)/documents/feedbackQuota/${a}`, s = { "Content-Type": "application/json" };
	i && (s.Authorization = `Bearer ${i}`);
	let c = await fetch(`${e.firestoreUrl}/v1/${o}`, { headers: s }), l = 1;
	if (c.ok) {
		let e = await c.json(), t = Number(e.fields?.count?.integerValue ?? 0);
		l = (Number.isFinite(t) ? t : 0) + 1;
	} else if (c.status !== 404) throw Error(`Firestore feedbackQuota get ${c.status}`);
	let u = [{
		update: {
			name: `projects/${e.projectId}/databases/(default)/documents/feedback/${a}_${l}`,
			fields: {
				text: { stringValue: n },
				uid: { stringValue: r },
				site: { stringValue: L(t.site, 100) },
				version: { stringValue: L(t.version, 32) },
				locale: { stringValue: L(t.locale, 16) },
				source: { stringValue: e.source }
			}
		},
		currentDocument: { exists: !1 },
		updateTransforms: [{
			fieldPath: "addedAt",
			setToServerValue: "REQUEST_TIME"
		}]
	}, {
		update: {
			name: o,
			fields: { count: { integerValue: String(l) } }
		},
		updateTransforms: [{
			fieldPath: "updatedAt",
			setToServerValue: "REQUEST_TIME"
		}]
	}], d = await fetch(`${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, {
		method: "POST",
		headers: s,
		body: JSON.stringify({ writes: u })
	});
	if (!d.ok) {
		let e = await d.text().catch(() => "");
		throw Error(`Firestore feedback commit ${d.status}: ${e || d.statusText}`);
	}
}
async function z(e, t) {
	let n = await k(e), r = `${n.uid}_${A()}`, i = [{
		update: {
			name: `projects/${e.projectId}/databases/(default)/documents/diagnostics/${r}`,
			fields: {
				kind: { stringValue: "no_subs_after_retry" },
				site: { stringValue: L(t.site, 100) },
				videoRef: { stringValue: L(t.videoRef, 500) },
				version: { stringValue: L(t.version, 32) },
				locale: { stringValue: L(t.locale, 16) },
				learning: { stringValue: L(t.learning, 16) },
				native: { stringValue: L(t.native, 16) },
				failure: { stringValue: L(t.failure ?? "", 32) },
				status: { integerValue: String(t.status ?? 0) },
				attempts: { integerValue: String(t.attempts ?? 0) },
				tracksLoaded: { integerValue: String(t.tracksLoaded ?? 0) },
				source: { stringValue: e.source }
			}
		},
		currentDocument: { exists: !1 },
		updateTransforms: [{
			fieldPath: "addedAt",
			setToServerValue: "REQUEST_TIME"
		}]
	}], a = await fetch(`${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${n.idToken}`
		},
		body: JSON.stringify({ writes: i })
	});
	if (!a.ok) {
		let e = await a.text().catch(() => "");
		throw Error(`Firestore diagnostics commit ${a.status}: ${e || a.statusText}`);
	}
}
async function B(e, t) {
	let n = I(t.term);
	if (n === 0 || n > D) throw Error(`term must be 1..${D} bytes (UTF-8)`);
	t.context && I(t.context) > O && (t = {
		...t,
		context: L(t.context, O)
	});
	let r = await k(e), i;
	try {
		i = await P(e, r.idToken, r.uid);
	} catch (t) {
		if (t instanceof Error && t.message === "Firestore sentinel 401") {
			let t = await w(e, r.refreshToken);
			r = {
				...r,
				...t
			}, await h(r), i = await P(e, r.idToken, r.uid);
		} else throw t;
	}
	let { writes: a, wordId: o, documentPath: s } = F(e, r.uid, t, i), c = `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, l = JSON.stringify({ writes: a }), u = await fetch(c, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${r.idToken}`
		},
		body: l
	});
	if (u.status === 401) {
		let t = await w(e, r.refreshToken);
		r = {
			...r,
			...t
		}, await h(r), u = await fetch(c, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${r.idToken}`
			},
			body: l
		});
	}
	if (!u.ok) {
		let e = await u.text().catch(() => "");
		throw Error(`Firestore commit ${u.status}: ${e || u.statusText}`);
	}
	return await u.json(), {
		wordId: o,
		documentPath: s
	};
}
//#endregion
//#region ../../packages/shared/src/analytics-bg.ts
var V = 864e5, H = 1800 * 1e3, U = [
	{
		day: 1,
		event: "retained_d2",
		key: f.d2Sent
	},
	{
		day: 6,
		event: "retained_d7",
		key: f.d7Sent
	},
	{
		day: 13,
		event: "retained_d14",
		key: f.d14Sent
	}
], W = null;
async function G() {
	if (W) return W;
	let e;
	try {
		e = (await chrome.storage.local.get(f.clientId))[f.clientId];
	} catch {
		return null;
	}
	if (typeof e == "string" && e) return W = e, e;
	let t = crypto.randomUUID();
	W = t;
	try {
		await chrome.storage.local.set({ [f.clientId]: t });
	} catch {}
	return t;
}
async function K(e = Date.now()) {
	try {
		let t = await chrome.storage.session.get([p.sessionId, p.sessionAt]), n = t[p.sessionId], r = Number(t[p.sessionAt] ?? 0);
		if (typeof n == "string" && n && e - r < H) return chrome.storage.session.set({ [p.sessionAt]: e }), n;
	} catch {}
	let t = crypto.randomUUID();
	try {
		await chrome.storage.session.set({
			[p.sessionId]: t,
			[p.sessionAt]: e
		});
	} catch {}
	return t;
}
async function q(e = Date.now()) {
	try {
		let t = await chrome.storage.local.get(f.installedAt), n = Number(t[f.installedAt] ?? 0);
		if (!n) return;
		let r = Math.floor((e - n) / V);
		return r >= 0 ? r : void 0;
	} catch {
		return;
	}
}
async function se(e = Date.now()) {
	try {
		if ((await chrome.storage.local.get(f.installedAt))[f.installedAt]) return;
		let t = Math.floor(e / V) * V;
		await chrome.storage.local.set({ [f.installedAt]: t });
	} catch {}
}
async function ce() {
	try {
		let e = (await chrome.storage.local.get(c))[c];
		if (typeof e != "object" || !e) return !0;
		let t = e.analyticsEnabled;
		return t === void 0 ? !0 : t === !0;
	} catch {
		return !1;
	}
}
function le() {
	return "https://www.google-analytics.com/mp/collect?measurement_id=G-09BWM1R5S5&api_secret=oZGdXkyMSJ6_3WZdeIFM0Q";
}
function ue() {
	try {
		return chrome.runtime.getManifest?.().version ?? "";
	} catch {
		return "";
	}
}
async function J(e) {
	await fetch(le(), {
		method: "POST",
		body: e,
		keepalive: !0
	});
}
var Y = null;
function de(e) {
	Y = e;
}
function fe() {
	try {
		return Y?.() || void 0;
	} catch {
		return;
	}
}
async function X(e, t = {}) {
	try {
		if (s() || e !== "analytics_opt_out" && !await ce()) return;
		let n = Date.now(), [r, i, a] = await Promise.all([
			G(),
			K(n),
			q(n)
		]);
		if (r === null) return;
		let c = {
			clientId: r,
			sessionId: i,
			daysSinceInstall: a,
			extSource: "youtube-extension",
			extVersion: ue(),
			extEnv: "prod",
			backend: fe()
		};
		await J(JSON.stringify(o(e, t, c))), await pe(a, c);
	} catch {}
}
async function pe(e, t) {
	if (typeof e != "number") return;
	let n = U.find((t) => t.day === e);
	if (n) try {
		if ((await chrome.storage.local.get(n.key))[n.key] === !0) return;
		await chrome.storage.local.set({ [n.key]: !0 }), await J(JSON.stringify(o(n.event, {}, t)));
	} catch {}
}
var me = new Set(e);
async function he(e) {
	let t = typeof e.event == "string" ? e.event : "";
	return me.has(t) ? (await X(t, typeof e.params == "object" && e.params !== null ? e.params : {}), { ok: !0 }) : { ok: !1 };
}
//#endregion
//#region ../../packages/shared/src/auth/devEnvSwitch.ts
var ge = {
	projectId: u.projectId,
	apiKey: u.apiKey,
	frontendBaseUrl: u.frontendBaseUrl
};
function _e() {
	return ge.projectId === "lingogram-prod";
}
//#endregion
//#region ../../packages/shared/src/auth/background.ts
var ve = new Set([
	"AUTH_STATUS",
	"AUTH_SIGN_IN_VIA_LINGOGRAM",
	"AUTH_SIGN_OUT",
	"OPEN_LINGOGRAM",
	"ADD_WORD",
	"REPORT_NO_SUBS",
	"SEND_FEEDBACK",
	"TRACK_EVENT"
]);
function ye(e) {
	return typeof e == "string" ? !!ve.has(e) : !1;
}
function Z() {
	try {
		chrome.action?.setBadgeText({ text: "!" }), chrome.action?.setBadgeBackgroundColor?.({ color: "#dc2626" });
	} catch {}
}
function Q() {
	try {
		chrome.action?.setBadgeText({ text: "" });
	} catch {}
}
function be(e) {
	if (!(e instanceof Error)) return !1;
	let t = e.message;
	return t.includes("Not signed in") || t.includes("Firebase REST 400") || t.includes("Firebase REST 401") || t.includes("Firebase REST 403") || t.includes("Firestore commit 401") || t.includes("Firestore commit 403") || t.includes("Firestore sentinel 401") || t.includes("INVALID_REFRESH_TOKEN") || t.includes("TOKEN_EXPIRED");
}
async function $(e) {
	switch (e.action) {
		case "AUTH_STATUS": {
			let e = await m(), t = await _();
			return e ? {
				signedIn: !0,
				email: e.email,
				uid: e.uid,
				inboxCount: t
			} : {
				signedIn: !1,
				inboxCount: t
			};
		}
		case "AUTH_SIGN_IN_VIA_LINGOGRAM": {
			let t = chrome.runtime.id, n = crypto.randomUUID();
			await ie(n), X("signin_started", { from: String(e.from ?? "unknown") });
			let r = `${u.frontendBaseUrl}/extension-auth?ext=${encodeURIComponent(t)}&nonce=${encodeURIComponent(n)}`;
			return await chrome.tabs.create({ url: r }), { ok: !0 };
		}
		case "OPEN_LINGOGRAM": return await chrome.tabs.create({ url: u.frontendBaseUrl }), { ok: !0 };
		case "AUTH_SIGN_OUT": return await g(), Q(), { ok: !0 };
		case "ADD_WORD": {
			let t = String(e.term ?? "").trim(), n = typeof e.context == "string" ? e.context : "";
			if (!t) throw Error("term required");
			let r = {
				term: t,
				context: n
			}, i = String(e.site ?? "");
			X("word_save_attempt", {
				site: i,
				signed_in: !!await m()
			});
			try {
				let e = await B(u, r), t = await ee(), n = await y(), a = !1;
				return n >= 5 && !await te() && (await ne(), a = !0), X("word_saved", {
					site: i,
					saved_count: n
				}), {
					ok: !0,
					wordId: e.wordId,
					inboxCount: t,
					promptRate: a
				};
			} catch (e) {
				throw be(e) && (await g(), Z()), e;
			}
		}
		case "TRACK_EVENT": return he(e);
		case "REPORT_NO_SUBS": {
			let t = String(e.videoRef ?? "");
			if (!t) return { ok: !1 };
			try {
				return await z(u, {
					site: String(e.site ?? ""),
					videoRef: t,
					version: String(e.version ?? ""),
					locale: String(e.locale ?? ""),
					learning: String(e.learning ?? ""),
					native: String(e.native ?? ""),
					failure: String(e.failure ?? ""),
					status: Number(e.status ?? 0),
					attempts: Number(e.attempts ?? 0),
					tracksLoaded: Number(e.tracksLoaded ?? 0)
				}), { ok: !0 };
			} catch {
				return { ok: !1 };
			}
		}
		case "SEND_FEEDBACK": {
			let t = String(e.text ?? "").trim();
			if (!t) return { ok: !1 };
			try {
				return await R(u, {
					text: t,
					site: String(e.site ?? ""),
					version: String(e.version ?? ""),
					locale: String(e.locale ?? "")
				}), { ok: !0 };
			} catch (e) {
				return console.warn("[Lingogram] feedback failed:", e), { ok: !1 };
			}
		}
		default: throw Error(`unknown action: ${e.action}`);
	}
}
function xe(e) {
	let t = /* @__PURE__ */ new Set();
	try {
		let n = new URL(e);
		if (t.add(n.origin), n.hostname.endsWith(".web.app")) {
			let e = n.hostname.replace(/\.web\.app$/, ".firebaseapp.com");
			t.add(`${n.protocol}//${e}`);
		} else if (n.hostname.endsWith(".firebaseapp.com")) {
			let e = n.hostname.replace(/\.firebaseapp\.com$/, ".web.app");
			t.add(`${n.protocol}//${e}`);
		}
	} catch {}
	return t;
}
var Se = xe(u.frontendBaseUrl);
function Ce(e) {
	let t = e.origin ?? (e.url ? new URL(e.url).origin : void 0);
	return !!t && Se.has(t);
}
function we() {
	chrome.runtime.onMessageExternal.addListener((e, t, n) => {
		if (!Ce(t)) return n({
			ok: !1,
			error: "unauthorized origin"
		}), !1;
		if (e?.type !== "lingogram-extension-auth") return n({
			ok: !1,
			error: "unknown message type"
		}), !1;
		let r = e.payload ?? {}, i = typeof r.customToken == "string" ? r.customToken : "", a = typeof r.email == "string" ? r.email : "", o = typeof r.uid == "string" ? r.uid : "", s = typeof r.nonce == "string" ? r.nonce : "";
		return !i || !o ? (n({
			ok: !1,
			error: "customToken and uid required"
		}), !1) : ((async () => {
			if (!await x(s)) {
				n({
					ok: !1,
					error: "invalid or expired auth challenge — open the extension popup and start the sign-in flow from there"
				});
				return;
			}
			try {
				let e = await T(u, i, o);
				await h({
					idToken: e.idToken,
					refreshToken: e.refreshToken,
					expiresAt: e.expiresAt,
					email: a,
					uid: e.uid
				}), await S(), Q(), n({ ok: !0 });
			} catch (e) {
				n({
					ok: !1,
					error: String(e instanceof Error ? e.message : e)
				});
			}
		})(), !0);
	});
}
function Te() {
	chrome.runtime.onMessage.addListener((e, t, n) => ye(e?.action) ? ((async () => {
		try {
			n(await $(e));
		} catch (e) {
			console.error("Background auth handler error:", e), n({
				ok: !1,
				error: String(e instanceof Error ? e.message : e)
			});
		}
	})(), !0) : !1);
}
async function Ee() {
	let e = await m();
	e && !e.refreshToken && (await g(), Z());
}
function De() {
	Te(), we(), Ee();
}
//#endregion
//#region ../../packages/shared/src/onboarding.ts
var Oe = `${u.frontendBaseUrl}/welcome/`, ke = `${u.frontendBaseUrl}/uninstall/`;
function Ae(e, t) {
	chrome.runtime.onInstalled.addListener((n) => {
		if (n.reason === chrome.runtime.OnInstalledReason.INSTALL) {
			t?.onInstall?.(), chrome.tabs.create({ url: `${Oe}?ext=${e}` });
			return;
		}
		n.reason === chrome.runtime.OnInstalledReason.UPDATE && t?.onUpdate?.(n.previousVersion ?? "");
	}), chrome.runtime.setUninstallURL(`${ke}?ext=${e}`);
}
chrome.runtime.onInstalled.addListener(() => {
	console.log("[YT-VTT bg] installed");
}), de(() => _e() ? "prod" : "preprod"), De(), Ae("youtube", {
	onInstall: () => {
		se(), X("extension_installed");
	},
	onUpdate: (e) => {
		X("extension_updated", { previous_version: e });
	}
});
//#endregion
