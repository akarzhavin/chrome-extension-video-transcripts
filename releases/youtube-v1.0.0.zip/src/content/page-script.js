(function() {
	//#region src/content/page-script.ts
	(function() {
		const TAG = "[YT-VTT page-script]";
		const originalFetch = window.fetch.bind(window);
		const potByVideoId = /* @__PURE__ */ new Map();
		const potWaitersByVideoId = /* @__PURE__ */ new Map();
		function tryCapturePot(url) {
			try {
				const u = new URL(url, location.href);
				if (!u.pathname.includes("/api/timedtext")) return;
				const v = u.searchParams.get("v");
				const pot = u.searchParams.get("pot");
				if (!v || !pot) return;
				if (!potByVideoId.has(v)) {
					potByVideoId.set(v, pot);
					console.log(TAG, "captured pot for", v);
				}
				const waiters = potWaitersByVideoId.get(v);
				if (waiters && waiters.size > 0) {
					const fns = [...waiters];
					potWaitersByVideoId.delete(v);
					fns.forEach((fn) => fn(pot));
				}
			} catch {}
		}
		function waitForPot(videoId, timeoutMs) {
			return new Promise((resolve) => {
				let done = false;
				const waiter = (pot) => {
					if (done) return;
					done = true;
					clearTimeout(timer);
					resolve(pot);
				};
				const timer = setTimeout(() => {
					if (done) return;
					done = true;
					const set = potWaitersByVideoId.get(videoId);
					if (set) {
						set.delete(waiter);
						if (set.size === 0) potWaitersByVideoId.delete(videoId);
					}
					resolve(null);
				}, timeoutMs);
				const set = potWaitersByVideoId.get(videoId) ?? /* @__PURE__ */ new Set();
				set.add(waiter);
				potWaitersByVideoId.set(videoId, set);
			});
		}
		const xhrOpen = XMLHttpRequest.prototype.open;
		XMLHttpRequest.prototype.open = function(method, url, ...rest) {
			try {
				const urlStr = typeof url === "string" ? url : url.href;
				if (urlStr.includes("/api/timedtext")) tryCapturePot(urlStr);
			} catch {}
			return xhrOpen.apply(this, [
				method,
				url,
				...rest
			]);
		};
		window.fetch = async function(...args) {
			try {
				const input = args[0];
				const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
				if (url && url.includes("/api/timedtext")) tryCapturePot(url);
			} catch {}
			return originalFetch.apply(window, args);
		};
		function postTracks(player) {
			const rawTracks = player.captions?.playerCaptionsTracklistRenderer?.captionTracks;
			const videoId = player.videoDetails?.videoId;
			if (!rawTracks || !videoId) return;
			const tracks = rawTracks.map((t) => ({
				baseUrl: t.baseUrl,
				lang: t.languageCode,
				name: t.name?.simpleText || t.name?.runs?.[0]?.text || t.languageCode,
				kind: t.kind
			}));
			console.log(TAG, "sending tracks for", videoId, tracks.map((t) => t.lang));
			window.postMessage({
				type: "YT_CAPTIONS_FOUND",
				videoId,
				tracks
			}, "*");
		}
		function readPlayerResponseFromYtdApp() {
			try {
				return document.getElementsByTagName("ytd-app")[0]?.data?.playerResponse ?? null;
			} catch {
				return null;
			}
		}
		async function readPlayerResponseWithRetry(maxAttempts = 50) {
			for (let i = 0; i < maxAttempts; i++) {
				const pr = readPlayerResponseFromYtdApp();
				if (pr?.videoDetails?.videoId && pr.captions) return pr;
				await new Promise((r) => setTimeout(r, 100));
			}
			return readPlayerResponseFromYtdApp();
		}
		async function broadcastCurrent() {
			const pr = await readPlayerResponseWithRetry();
			if (pr) postTracks(pr);
		}
		document.addEventListener("yt-navigate-finish", () => {
			setTimeout(broadcastCurrent, 200);
		});
		function clickCcButton() {
			const btn = document.querySelector(".ytp-subtitles-button");
			if (btn) {
				btn.click();
				return true;
			}
			return false;
		}
		function fireCcKey() {
			const video = document.querySelector("video");
			if (!video) return;
			const init = {
				key: "c",
				code: "KeyC",
				keyCode: 67,
				which: 67,
				bubbles: true,
				cancelable: true
			};
			video.dispatchEvent(new KeyboardEvent("keydown", init));
			video.dispatchEvent(new KeyboardEvent("keyup", init));
		}
		function toggleCc() {
			if (!clickCcButton()) fireCcKey();
		}
		const inFlightEnsurePot = /* @__PURE__ */ new Map();
		async function generatePotForVideo(videoId) {
			for (let i = 0; i < 20; i++) {
				if (document.querySelector(".ytp-subtitles-button")) break;
				await new Promise((r) => setTimeout(r, 200));
			}
			console.log(TAG, "pot not yet seen, toggling CC for", videoId);
			const wait = waitForPot(videoId, 15e3);
			toggleCc();
			const pot = await wait;
			toggleCc();
			return pot;
		}
		async function ensurePot(videoId) {
			const own = potByVideoId.get(videoId);
			if (own) return own;
			const existing = inFlightEnsurePot.get(videoId);
			if (existing) return existing;
			const p = generatePotForVideo(videoId).finally(() => {
				inFlightEnsurePot.delete(videoId);
			});
			inFlightEnsurePot.set(videoId, p);
			return p;
		}
		function buildUrl(baseUrl, pot, tlang) {
			const u = new URL(baseUrl, location.href);
			u.searchParams.set("fmt", "json3");
			u.searchParams.set("c", "WEB");
			u.searchParams.set("pot", pot);
			if (tlang) u.searchParams.set("tlang", tlang);
			return u.toString();
		}
		function isUsableResponse(text) {
			if (!text || text.length < 20) return false;
			if (!text.includes("\"events\"")) return false;
			return true;
		}
		async function fetchOnce(url) {
			const res = await originalFetch(url, { credentials: "include" });
			if (!res.ok) throw new Error("HTTP " + res.status);
			return await res.text();
		}
		async function fetchVtt(reqKey, baseUrl, videoId, tlang) {
			const pot = await ensurePot(videoId);
			if (!pot) {
				console.warn(TAG, "no pot for", videoId);
				window.postMessage({
					type: "YT_VTT_RESULT",
					url: reqKey,
					text: "",
					error: "no_pot"
				}, "*");
				return;
			}
			const url = buildUrl(baseUrl, pot, tlang);
			let text = "";
			let lastErr = null;
			for (let attempt = 1; attempt <= 4; attempt++) {
				try {
					text = await fetchOnce(url);
					if (isUsableResponse(text)) {
						console.log(TAG, "fetched", text.length, "bytes for", reqKey, attempt > 1 ? `(attempt ${attempt})` : "");
						window.postMessage({
							type: "YT_VTT_RESULT",
							url: reqKey,
							text
						}, "*");
						return;
					}
					console.warn(TAG, "empty/invalid response for", reqKey, "attempt", attempt, "bytes:", text.length);
				} catch (e) {
					lastErr = e;
					console.warn(TAG, "fetch attempt", attempt, "failed for", reqKey, e);
				}
				await new Promise((r) => setTimeout(r, 400 * attempt));
			}
			console.warn(TAG, "giving up on", reqKey, "after retries");
			window.postMessage({
				type: "YT_VTT_RESULT",
				url: reqKey,
				text,
				error: lastErr ? String(lastErr) : "empty_after_retries"
			}, "*");
		}
		window.addEventListener("message", (event) => {
			if (event.source !== window) return;
			const data = event.data;
			if (!data) return;
			if (data.type === "YT_QUERY_CAPTIONS") {
				broadcastCurrent();
				return;
			}
			if (data.type === "YT_FETCH_VTT" && typeof data.url === "string" && typeof data.baseUrl === "string" && typeof data.videoId === "string") fetchVtt(data.url, data.baseUrl, data.videoId, data.tlang);
		});
		console.log(TAG, "installed");
	})();
	//#endregion
})();
