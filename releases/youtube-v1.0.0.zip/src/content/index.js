(function() {
(function() {
	//#region ../../packages/shared/src/AppState.ts
	var AppState = class {
		tracks = [];
		activeTrackIndex = 0;
		secondaryTrackIndex = 0;
		displayMode = "dual";
		overlayEnabled = true;
		currentIndex = -1;
		isHovering = false;
		guessState = /* @__PURE__ */ new Map();
		addTrack(name, subtitles) {
			this.tracks.push({
				name,
				subtitles
			});
			this.applyPreferences();
		}
		reset() {
			this.tracks = [];
			this.activeTrackIndex = 0;
			this.secondaryTrackIndex = 0;
			this.currentIndex = -1;
			this.guessState.clear();
		}
		applyPreferences() {
			if (this.tracks.length === 0) return;
			const engIndex = this.tracks.findIndex((t) => t.name.includes("English"));
			const rusIndex = this.tracks.findIndex((t) => t.name.includes("Russian") || t.name.includes("Ukrainian"));
			if (engIndex !== -1) {
				this.activeTrackIndex = engIndex;
				if (rusIndex !== -1) this.secondaryTrackIndex = rusIndex;
				else if (this.tracks.length > 1) this.secondaryTrackIndex = engIndex === 0 ? 1 : 0;
			} else if (rusIndex !== -1) {
				this.activeTrackIndex = rusIndex;
				if (this.tracks.length > 1) this.secondaryTrackIndex = rusIndex === 0 ? 1 : 0;
			} else {
				this.activeTrackIndex = 0;
				if (this.tracks.length > 1) this.secondaryTrackIndex = 1;
			}
		}
		isDuplicate(newSubs) {
			return this.tracks.some((track) => track.subtitles.length > 0 && track.subtitles[0].text === newSubs[0].text && track.subtitles[Math.floor(track.subtitles.length / 2)]?.text === newSubs[Math.floor(newSubs.length / 2)]?.text);
		}
		hasMultipleTracks() {
			return this.tracks.length > 1;
		}
		swapTracks() {
			if (this.hasMultipleTracks()) {
				[this.activeTrackIndex, this.secondaryTrackIndex] = [this.secondaryTrackIndex, this.activeTrackIndex];
				return true;
			}
			return false;
		}
		toggleDualMode() {
			if (this.hasMultipleTracks()) {
				this.displayMode = this.displayMode === "single" ? "dual" : "single";
				return true;
			}
			return false;
		}
		toggleGuessMode() {
			if (this.displayMode === "guess") this.displayMode = "dual";
			else {
				this.displayMode = "guess";
				this.resetGuessState();
			}
			return true;
		}
		revealNextWord(index) {
			const mainTrack = this.getMainTrack();
			if (!mainTrack || !mainTrack[index]) return false;
			const words = mainTrack[index].text.split(/\s+/);
			const current = this.guessState.get(index) ?? 1;
			if (current >= words.length) return true;
			this.guessState.set(index, current + 1);
			return current + 1 >= words.length;
		}
		getRevealedCount(index) {
			return this.guessState.get(index) ?? 1;
		}
		isFullyRevealed(index) {
			const mainTrack = this.getMainTrack();
			if (!mainTrack || !mainTrack[index]) return false;
			const words = mainTrack[index].text.split(/\s+/);
			return this.getRevealedCount(index) >= words.length;
		}
		resetGuessState() {
			this.guessState.clear();
		}
		getMainTrack() {
			return this.tracks[this.activeTrackIndex]?.subtitles || null;
		}
		getSecondaryTrack() {
			return this.hasMultipleTracks() ? this.tracks[this.secondaryTrackIndex]?.subtitles : null;
		}
		getOverlappingSecondary(sub) {
			const secondary = this.getSecondaryTrack();
			if (!secondary) return [];
			return secondary.filter((s) => s.startTime < sub.endTime && s.endTime > sub.startTime);
		}
	};
	//#endregion
	//#region ../../packages/shared/src/SidebarUI.ts
	var NEARBY_SUBTITLE_THRESHOLD = 20;
	var SidebarUI = class {
		state;
		app;
		elements;
		hoverStartIndex = -1;
		constructor(state, app) {
			this.state = state;
			this.app = app;
			this.elements = {};
		}
		init() {
			if (document.getElementById("vtt-sidebar")) return false;
			const sidebar = document.createElement("div");
			sidebar.id = "vtt-sidebar";
			const toggleBtn = document.createElement("div");
			toggleBtn.id = "vtt-toggle-btn";
			toggleBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>`;
			toggleBtn.addEventListener("click", () => sidebar.classList.toggle("collapsed"));
			sidebar.appendChild(toggleBtn);
			const header = document.createElement("div");
			header.id = "vtt-header";
			const headerTop = document.createElement("div");
			headerTop.id = "vtt-header-top";
			headerTop.innerHTML = `<h2>Subtitles</h2>`;
			const settingsBtn = document.createElement("div");
			settingsBtn.id = "vtt-settings-btn";
			settingsBtn.title = "Settings";
			settingsBtn.style.display = "flex";
			settingsBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>`;
			settingsBtn.addEventListener("click", () => this.elements.settingsPanel?.classList.toggle("open"));
			headerTop.appendChild(settingsBtn);
			header.appendChild(headerTop);
			const settingsPanel = document.createElement("div");
			settingsPanel.id = "vtt-settings-panel";
			const selectorsDiv = document.createElement("div");
			selectorsDiv.id = "vtt-track-selectors";
			const mainSelect = document.createElement("select");
			mainSelect.id = "vtt-main-select";
			mainSelect.title = "Main Track";
			mainSelect.className = "vtt-select";
			mainSelect.addEventListener("change", (e) => {
				const target = e.target;
				this.state.activeTrackIndex = parseInt(target.value);
				this.refresh();
			});
			const subSelect = document.createElement("select");
			subSelect.id = "vtt-sub-select";
			subSelect.title = "Secondary Track";
			subSelect.className = "vtt-select";
			subSelect.addEventListener("change", (e) => {
				const target = e.target;
				this.state.secondaryTrackIndex = parseInt(target.value);
				this.refresh();
			});
			selectorsDiv.appendChild(mainSelect);
			selectorsDiv.appendChild(subSelect);
			settingsPanel.appendChild(selectorsDiv);
			const controls = document.createElement("div");
			controls.id = "vtt-controls";
			const swapBtn = document.createElement("button");
			swapBtn.id = "vtt-swap-btn";
			swapBtn.title = "Swap Language (Shift+S)";
			swapBtn.textContent = "🔄 Swap";
			swapBtn.addEventListener("click", () => {
				if (this.state.swapTracks()) this.refresh();
			});
			controls.appendChild(swapBtn);
			const dualBtn = document.createElement("button");
			dualBtn.id = "vtt-dual-btn";
			dualBtn.title = "Toggle Dual Mode (Shift+D)";
			dualBtn.textContent = "📖 Dual";
			dualBtn.addEventListener("click", () => {
				if (this.state.toggleDualMode()) this.refresh();
			});
			controls.appendChild(dualBtn);
			const guessBtn = document.createElement("button");
			guessBtn.id = "vtt-guess-btn";
			guessBtn.title = "Toggle Guess Mode (Shift+G)";
			guessBtn.textContent = "🧩 Guess";
			guessBtn.addEventListener("click", () => {
				if (this.state.toggleGuessMode()) this.refresh();
			});
			controls.appendChild(guessBtn);
			const overlayBtn = document.createElement("button");
			overlayBtn.id = "vtt-overlay-btn";
			overlayBtn.title = "Toggle On-Screen Overlay (Shift+O)";
			overlayBtn.textContent = "📺 Overlay";
			overlayBtn.addEventListener("click", () => {
				this.state.overlayEnabled = !this.state.overlayEnabled;
				this.refresh();
			});
			controls.appendChild(overlayBtn);
			settingsPanel.appendChild(controls);
			header.appendChild(settingsPanel);
			sidebar.appendChild(header);
			const list = document.createElement("div");
			list.id = "vtt-list";
			sidebar.appendChild(list);
			document.body.appendChild(sidebar);
			this.elements = {
				sidebar,
				settingsBtn,
				settingsPanel,
				mainSelect,
				subSelect,
				dualBtn,
				overlayBtn,
				list
			};
			sidebar.addEventListener("mouseenter", () => {
				this.state.isHovering = true;
				this.hoverStartIndex = this.state.currentIndex;
			});
			sidebar.addEventListener("mouseleave", () => {
				this.state.isHovering = false;
				this.scrollActiveIntoView(this.pickScrollMode(this.state.currentIndex, this.hoverStartIndex));
			});
			if (window === window.top) document.body.classList.add("vtt-sidebar-active");
			else sidebar.style.display = "none";
			this.setupFullscreenHandling();
			return true;
		}
		setupFullscreenHandling() {
			document.addEventListener("fullscreenchange", () => {
				const sidebar = this.elements.sidebar;
				if (!sidebar) return;
				if (document.fullscreenElement) {
					sidebar.style.display = "flex";
					sidebar.classList.add("fullscreen");
					sidebar.classList.add("collapsed");
					document.fullscreenElement.appendChild(sidebar);
				} else {
					document.body.appendChild(sidebar);
					sidebar.classList.remove("fullscreen");
					if (!(window === window.top)) sidebar.style.display = "none";
					else sidebar.classList.remove("collapsed");
				}
				this.scrollActiveIntoView("instant");
			});
		}
		pickScrollMode(targetIndex, fromIndex) {
			if (fromIndex === -1) return "instant";
			return Math.abs(targetIndex - fromIndex) <= NEARBY_SUBTITLE_THRESHOLD ? "smooth" : "instant";
		}
		scrollActiveIntoView(mode) {
			(this.elements.list?.querySelector(".vtt-item.active-sub"))?.scrollIntoView({
				behavior: mode,
				block: "center"
			});
		}
		buildSecondaryTextElement(overlap, className = "vtt-sub-text") {
			if (overlap.length === 0) return null;
			const div = document.createElement("div");
			div.className = className;
			div.textContent = overlap.map((s) => s.text).join(" | ");
			return div;
		}
		refresh() {
			this.updateControls();
			this.renderSubtitles();
			this.app.updateHighlight();
		}
		updateControls() {
			if (!this.elements.settingsBtn || !this.elements.dualBtn || !this.elements.overlayBtn || !this.elements.mainSelect || !this.elements.subSelect) return;
			this.elements.settingsBtn.style.display = "flex";
			const hasMultiple = this.state.hasMultipleTracks();
			this.elements.dualBtn.classList.toggle("active", this.state.displayMode === "dual");
			this.elements.overlayBtn.classList.toggle("active", this.state.overlayEnabled);
			const guessBtn = document.getElementById("vtt-guess-btn");
			if (guessBtn) guessBtn.classList.toggle("active", this.state.displayMode === "guess");
			const activeId = document.activeElement?.id;
			this.elements.mainSelect.innerHTML = "";
			this.elements.subSelect.innerHTML = "";
			this.state.tracks.forEach((track, i) => {
				this.elements.mainSelect?.appendChild(new Option("Main: " + track.name, i.toString(), false, i === this.state.activeTrackIndex));
				this.elements.subSelect?.appendChild(new Option("Sub: " + track.name, i.toString(), false, i === this.state.secondaryTrackIndex));
			});
			this.elements.dualBtn.disabled = !hasMultiple;
			const swapBtn = document.getElementById("vtt-swap-btn");
			if (swapBtn) swapBtn.disabled = !hasMultiple;
			if (activeId) {
				const activeEl = document.getElementById(activeId);
				if (activeEl) activeEl.focus();
			}
		}
		buildMaskedContent(text, revealedCount) {
			const container = document.createElement("div");
			container.className = "vtt-main-text";
			text.split(/\s+/).forEach((word, i) => {
				if (i > 0) container.appendChild(document.createTextNode(" "));
				const span = document.createElement("span");
				if (i < revealedCount) {
					span.className = "vtt-revealed-word";
					span.textContent = word;
				} else {
					span.className = "vtt-masked-word";
					span.textContent = "***";
				}
				container.appendChild(span);
			});
			return container;
		}
		getMaskedText(text, revealedCount) {
			return text.split(/\s+/).map((w, i) => i < revealedCount ? w : "***").join(" ");
		}
		updateGuessItem(index) {
			if (!this.elements.list) return;
			const item = this.elements.list.querySelector(`.vtt-item[data-index="${index}"]`);
			if (!item) return;
			const mainTrack = this.state.getMainTrack();
			if (!mainTrack || !mainTrack[index]) return;
			const oldMain = item.querySelector(".vtt-main-text");
			const revealedCount = this.state.getRevealedCount(index);
			const newMain = this.buildMaskedContent(mainTrack[index].text, revealedCount);
			if (oldMain) item.replaceChild(newMain, oldMain);
			if (this.state.isFullyRevealed(index)) {
				item.classList.add("fully-revealed");
				if (!item.querySelector(".vtt-sub-text")) {
					const subText = this.buildSecondaryTextElement(this.state.getOverlappingSecondary(mainTrack[index]));
					if (subText) item.appendChild(subText);
				}
			}
		}
		renderSubtitles() {
			if (!this.elements.list) return;
			this.elements.list.innerHTML = "";
			this.state.currentIndex = -1;
			const mainTrack = this.state.getMainTrack();
			if (!mainTrack) return;
			const isGuessMode = this.state.displayMode === "guess";
			const df = document.createDocumentFragment();
			mainTrack.forEach((sub, index) => {
				df.appendChild(isGuessMode ? this.buildGuessItem(sub, index) : this.buildPlainItem(sub, index));
			});
			this.elements.list.appendChild(df);
		}
		createSubtitleItem(index) {
			const item = document.createElement("div");
			item.className = "vtt-item";
			item.dataset.index = index.toString();
			return item;
		}
		buildGuessItem(sub, index) {
			const item = this.createSubtitleItem(index);
			item.appendChild(this.buildMaskedContent(sub.text, this.state.getRevealedCount(index)));
			if (this.state.isFullyRevealed(index)) {
				item.classList.add("fully-revealed");
				const subText = this.buildSecondaryTextElement(this.state.getOverlappingSecondary(sub));
				if (subText) item.appendChild(subText);
			}
			item.addEventListener("click", () => {
				this.state.revealNextWord(index);
				this.updateGuessItem(index);
				this.app.seekVideo(sub.startTime);
			});
			return item;
		}
		buildPlainItem(sub, index) {
			const item = this.createSubtitleItem(index);
			const mainText = document.createElement("div");
			mainText.className = "vtt-main-text";
			mainText.textContent = sub.text;
			item.appendChild(mainText);
			if (this.state.displayMode === "dual") {
				const subText = this.buildSecondaryTextElement(this.state.getOverlappingSecondary(sub));
				if (subText) item.appendChild(subText);
			}
			item.addEventListener("click", () => this.app.seekVideo(sub.startTime));
			return item;
		}
		highlightSubtitle(currentTime) {
			const mainTrack = this.state.getMainTrack();
			if (!mainTrack || !this.elements.list) return;
			const activeIndex = mainTrack.findIndex((s) => currentTime >= s.startTime && currentTime <= s.endTime);
			if (activeIndex !== this.state.currentIndex) {
				this.moveActiveSubtitleClass(activeIndex);
				this.state.currentIndex = activeIndex;
			}
			this.updateOverlay(this.state.currentIndex);
		}
		moveActiveSubtitleClass(newIndex) {
			if (!this.elements.list) return;
			this.elements.list.querySelector(".vtt-item.active-sub")?.classList.remove("active-sub");
			if (newIndex === -1) return;
			const newActive = this.elements.list.querySelector(`.vtt-item[data-index="${newIndex}"]`);
			if (!newActive) return;
			newActive.classList.add("active-sub");
			if (!this.state.isHovering) {
				const mode = this.pickScrollMode(newIndex, this.state.currentIndex);
				newActive.scrollIntoView({
					behavior: mode,
					block: "center"
				});
			}
		}
		updateOverlay(index) {
			const existing = document.getElementById("vtt-video-overlay");
			if (!this.state.overlayEnabled) {
				if (existing) existing.style.display = "none";
				return;
			}
			const desiredParent = this.app.getOverlayParent?.() ?? document.querySelector("video")?.parentElement ?? null;
			if (existing && desiredParent && existing.parentElement !== desiredParent) existing.remove();
			const overlay = document.getElementById("vtt-video-overlay") ?? this.createOverlayElement();
			if (!overlay) return;
			overlay.style.display = "flex";
			overlay.innerHTML = "";
			const sub = index === -1 ? null : this.state.getMainTrack()?.[index];
			if (!sub) return;
			overlay.appendChild(this.buildOverlayMain(sub, index));
			if (this.shouldShowOverlayTranslation(index)) {
				const subDiv = this.buildSecondaryTextElement(this.state.getOverlappingSecondary(sub), "vtt-overlay-sub");
				if (subDiv) overlay.appendChild(subDiv);
			}
		}
		createOverlayElement() {
			const parent = this.app.getOverlayParent?.() ?? document.querySelector("video")?.parentElement;
			if (!parent) return null;
			const overlay = document.createElement("div");
			overlay.id = "vtt-video-overlay";
			parent.appendChild(overlay);
			return overlay;
		}
		buildOverlayMain(sub, index) {
			const mainDiv = document.createElement("div");
			mainDiv.className = "vtt-overlay-main";
			mainDiv.textContent = this.state.displayMode === "guess" ? this.getMaskedText(sub.text, this.state.getRevealedCount(index)) : sub.text;
			return mainDiv;
		}
		shouldShowOverlayTranslation(index) {
			if (this.state.displayMode === "dual") return true;
			if (this.state.displayMode === "guess") return this.state.isFullyRevealed(index);
			return false;
		}
	};
	//#endregion
	//#region src/content/json3.ts
	function parseJson3(jsonText) {
		if (!jsonText) return [];
		let data;
		try {
			data = JSON.parse(jsonText);
		} catch {
			return [];
		}
		if (!data?.events) return [];
		const subs = [];
		for (const e of data.events) {
			if (!e.segs || e.tStartMs === void 0) continue;
			const text = e.segs.map((s) => s.utf8 || "").join("").replace(/\s+/g, " ").trim();
			if (!text) continue;
			const startTime = e.tStartMs / 1e3;
			const endTime = startTime + (e.dDurationMs ?? 0) / 1e3;
			subs.push({
				startTime,
				endTime,
				text
			});
		}
		for (let i = 0; i < subs.length - 1; i++) if (subs[i].endTime > subs[i + 1].startTime) subs[i].endTime = Math.max(subs[i].startTime, subs[i + 1].startTime - .001);
		return subs;
	}
	//#endregion
	//#region src/content/index.ts
	var YouTubeVttApp = class {
		state;
		ui;
		detector;
		pendingRequests = /* @__PURE__ */ new Map();
		constructor() {
			this.state = new AppState();
			this.ui = new SidebarUI(this.state, this);
			this.detector = new YouTubeCaptionDetector(this);
			console.log("[YT-VTT] content script running");
			this.ui.init();
			this.updateSidebarVisibility();
			this.setupListeners();
			this.startVideoPolling();
			this.detector.start();
		}
		updateSidebarVisibility() {
			if (window !== window.top) return;
			const sidebar = document.getElementById("vtt-sidebar");
			if (!sidebar) return;
			if (this.detector.getVideoIdFromUrl() !== null) {
				sidebar.style.display = "";
				document.body.classList.add("vtt-sidebar-active");
			} else {
				sidebar.style.display = "none";
				document.body.classList.remove("vtt-sidebar-active");
			}
		}
		isAdPlaying() {
			const player = document.querySelector("#movie_player, .html5-video-player");
			return !!player && player.classList.contains("ad-showing");
		}
		startVideoPolling() {
			setInterval(() => {
				document.querySelectorAll("video").forEach((video) => {
					if (!video.dataset.vttAttached) {
						video.dataset.vttAttached = "true";
						video.addEventListener("timeupdate", () => {
							if (this.isAdPlaying()) return;
							this.ui.highlightSubtitle(video.currentTime);
						});
					}
				});
			}, 1e3);
		}
		setupListeners() {
			window.addEventListener("message", (event) => {
				if (event.source !== window) return;
				if (event.data?.type === "YT_VTT_RESULT") this.handleVttLoaded(event.data.url, event.data.text || "");
			});
			document.addEventListener("keydown", (e) => {
				if (e.shiftKey && e.code === "KeyS") {
					if (this.state.swapTracks()) this.ui.refresh();
				}
				if (e.shiftKey && e.code === "KeyD") {
					if (this.state.toggleDualMode()) this.ui.refresh();
				}
				if (e.shiftKey && e.code === "KeyO") {
					this.state.overlayEnabled = !this.state.overlayEnabled;
					this.ui.refresh();
				}
				if (e.shiftKey && e.code === "KeyG") {
					if (this.state.toggleGuessMode()) this.ui.refresh();
				}
			});
		}
		requestVtt(req, videoId) {
			this.pendingRequests.set(req.key, req.name);
			console.log("[YT-VTT] FETCH_VTT ->", req.name);
			window.postMessage({
				type: "YT_FETCH_VTT",
				url: req.key,
				baseUrl: req.baseUrl,
				videoId,
				tlang: req.tlang
			}, "*");
		}
		handleVttLoaded(url, vttText) {
			const name = this.pendingRequests.get(url);
			console.log("[YT-VTT] VTT_LOADED <-", name, "bytes:", vttText?.length ?? 0);
			if (!name) return;
			this.pendingRequests.delete(url);
			const subs = parseJson3(vttText);
			console.log("[YT-VTT] parsed subs:", subs.length, "for", name);
			if (subs.length === 0) return;
			if (!this.state.isDuplicate(subs)) this.state.addTrack(name, subs);
			this.ui.refresh();
		}
		resetForNewVideo() {
			this.pendingRequests.clear();
			this.state.reset();
			this.ui.refresh();
		}
		seekVideo(time) {
			const video = document.querySelector("video");
			if (video) {
				video.currentTime = time;
				video.play().catch(() => {});
			}
		}
		updateHighlight() {
			if (this.isAdPlaying()) return;
			const video = document.querySelector("video");
			if (video) this.ui.highlightSubtitle(video.currentTime);
		}
		getOverlayParent() {
			return document.querySelector("#movie_player") ?? document.querySelector("video")?.parentElement ?? null;
		}
	};
	var YouTubeCaptionDetector = class {
		app;
		currentVideoId = null;
		captionsLoadedForVideo = null;
		constructor(app) {
			this.app = app;
		}
		start() {
			window.addEventListener("message", (event) => {
				if (event.source !== window) return;
				if (event.data?.type === "YT_CAPTIONS_FOUND") this.handleCaptionTracks(event.data.videoId, event.data.tracks);
			});
			document.addEventListener("yt-navigate-finish", () => {
				this.checkCurrentVideo();
				this.app.updateSidebarVisibility();
			});
			let lastVideoId = this.getVideoIdFromUrl();
			setInterval(() => {
				const id = this.getVideoIdFromUrl();
				if (id !== lastVideoId) {
					lastVideoId = id;
					this.checkCurrentVideo();
					this.app.updateSidebarVisibility();
				}
			}, 1e3);
			window.postMessage({ type: "YT_QUERY_CAPTIONS" }, "*");
		}
		getVideoIdFromUrl() {
			try {
				const url = new URL(location.href);
				if (url.pathname === "/watch") return url.searchParams.get("v");
				if (url.pathname.startsWith("/shorts/")) return url.pathname.split("/")[2] || null;
			} catch {}
			return null;
		}
		checkCurrentVideo() {
			const id = this.getVideoIdFromUrl();
			if (!id || id === this.currentVideoId) return;
			this.currentVideoId = id;
			this.captionsLoadedForVideo = null;
			this.app.resetForNewVideo();
			window.postMessage({ type: "YT_QUERY_CAPTIONS" }, "*");
		}
		handleCaptionTracks(videoId, tracks) {
			if (!videoId || !tracks || tracks.length === 0) return;
			const currentId = this.getVideoIdFromUrl();
			if (currentId && videoId !== currentId) return;
			if (videoId !== this.currentVideoId) {
				this.currentVideoId = videoId;
				this.captionsLoadedForVideo = null;
				this.app.resetForNewVideo();
			}
			if (this.captionsLoadedForVideo === videoId) return;
			this.captionsLoadedForVideo = videoId;
			console.log("[YT-VTT] caption tracks for", videoId, tracks.map((t) => t.lang));
			this.buildTrackRequests(tracks, videoId).forEach((req) => this.app.requestVtt(req, videoId));
		}
		buildTrackRequests(tracks, videoId) {
			const requests = [];
			const isEnglish = (t) => t.lang === "en" || t.lang.startsWith("en-");
			const isRussian = (t) => t.lang === "ru" || t.lang.startsWith("ru-");
			const englishTrack = tracks.find(isEnglish);
			const russianTrack = tracks.find(isRussian);
			const mkKey = (name) => `${videoId}:${name}`;
			if (englishTrack) {
				requests.push({
					key: mkKey("English"),
					name: "English",
					baseUrl: englishTrack.baseUrl
				});
				if (russianTrack) requests.push({
					key: mkKey("Russian"),
					name: "Russian",
					baseUrl: russianTrack.baseUrl
				});
				else requests.push({
					key: mkKey("Russian"),
					name: "Russian",
					baseUrl: englishTrack.baseUrl,
					tlang: "ru"
				});
			} else if (tracks.length > 0) {
				const primary = tracks[0];
				const primaryName = primary.name || primary.lang;
				requests.push({
					key: mkKey(primaryName),
					name: primaryName,
					baseUrl: primary.baseUrl
				});
				if (russianTrack && russianTrack !== primary) requests.push({
					key: mkKey("Russian"),
					name: "Russian",
					baseUrl: russianTrack.baseUrl
				});
				else if (!isRussian(primary)) requests.push({
					key: mkKey("Russian"),
					name: "Russian",
					baseUrl: primary.baseUrl,
					tlang: "ru"
				});
			}
			return requests;
		}
	};
	function injectLayoutOverrides() {
		const style = document.createElement("style");
		style.id = "yt-vtt-layout";
		style.textContent = `
        body.vtt-sidebar-active:has(#vtt-sidebar:not(.collapsed):not(.fullscreen)) ytd-app {
            width: calc(100vw - 320px) !important;
            min-width: 0 !important;
        }
        body.vtt-sidebar-active:has(#vtt-sidebar:not(.collapsed):not(.fullscreen)) #masthead-container.ytd-app {
            width: calc(100vw - 320px) !important;
        }
        body.vtt-sidebar-active ytd-app {
            transition: width 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
    `;
		(document.head || document.documentElement).appendChild(style);
	}
	function watchSidebarState() {
		const fire = () => window.dispatchEvent(new Event("resize"));
		const startObservingSidebar = () => {
			const sidebar = document.getElementById("vtt-sidebar");
			if (!sidebar) return false;
			new MutationObserver(fire).observe(sidebar, {
				attributes: true,
				attributeFilter: ["class"]
			});
			return true;
		};
		if (!startObservingSidebar()) {
			const t = setInterval(() => {
				if (startObservingSidebar()) clearInterval(t);
			}, 200);
		}
		new MutationObserver(fire).observe(document.body, {
			attributes: true,
			attributeFilter: ["class"]
		});
		document.addEventListener("fullscreenchange", fire);
		setTimeout(fire, 500);
	}
	function bootstrap() {
		if (!window.location.hostname.includes("youtube.com")) return;
		injectLayoutOverrides();
		new YouTubeVttApp();
		watchSidebarState();
	}
	bootstrap();
	//#endregion
})();

})();