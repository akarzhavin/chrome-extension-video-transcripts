//#region src/background/background.ts
chrome.runtime.onInstalled.addListener(() => {
	console.log("[YT-VTT bg] installed");
});
//#endregion
