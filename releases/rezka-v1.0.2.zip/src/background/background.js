//#region src/background/background.ts
async function e(e, t = 3, n = 1e3) {
	for (let r = 0; r < t; r++) try {
		let t = await fetch(e);
		if (!t.ok) throw Error(`HTTP error! status: ${t.status}`);
		return await t.text();
	} catch (i) {
		if (console.warn(`Fetch attempt ${r + 1} failed for ${e}:`, i.message), r < t - 1) await new Promise((e) => setTimeout(e, n));
		else throw i;
	}
	throw Error(`Failed to fetch ${e} after ${t} attempts`);
}
chrome.runtime.onMessage.addListener((t, n, r) => (t.action === "TIME_UPDATE" || t.action === "SEEK_VIDEO" || t.action === "VTT_LOADED" ? n.tab && n.tab.id && chrome.tabs.sendMessage(n.tab.id, t) : t.action === "FETCH_VTT" && e(t.url).then((e) => {
	n.tab && n.tab.id && chrome.tabs.sendMessage(n.tab.id, {
		action: "VTT_LOADED",
		payload: e,
		url: t.url
	});
}).catch((e) => {
	console.error("Background: Failed to fetch VTT:", e);
}), !0));
//#endregion
export { e as fetchWithRetry };
