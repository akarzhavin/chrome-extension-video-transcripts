//#region ../../packages/shared/src/SidebarUI.ts
function e(e) {
	return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${e}</svg>`;
}
e("<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z\"/>"), e("<path d=\"M15 18l-6-6 6-6\"/>"), e("<path d=\"M4 6h16M4 12h16M4 18h10\"/>"), e("<path d=\"M2 6s3-2 10-2 10 2 10 2v12s-3-2-10-2-10 2-10 2z\" opacity=\".4\"/><path d=\"M12 4v14\"/>"), e("<path d=\"M4 7V5h16v2M9 19h6M12 5v14\"/>"), e("<path d=\"M6 9l6 6 6-6\"/>"), e("<path d=\"M7 16V4m0 0L3 8m4-4l4 4M17 8v12m0 0l4-4m-4 4l-4-4\"/>"), e("<rect x=\"3\" y=\"5\" width=\"18\" height=\"6\" rx=\"1.5\"/><rect x=\"3\" y=\"13.5\" width=\"18\" height=\"6\" rx=\"1.5\"/>"), e("<rect x=\"3\" y=\"5\" width=\"18\" height=\"6\" rx=\"1.5\"/><circle cx=\"6.5\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"17.5\" cy=\"16.5\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/>"), e("<rect x=\"2\" y=\"4\" width=\"20\" height=\"14\" rx=\"2\"/><path d=\"M6 14.5h12\"/>"), e("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 17h8\"/>"), e("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 13h8\"/>"), e("<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><path d=\"M8 9h8\"/>");
//#endregion
//#region ../../packages/shared/src/auth/config.ts
var t = {
	env: "prod",
	projectId: "lingogram-prod",
	apiKey: "AIzaSyCHQt2zwkO-x8qm7wM5IwWAWrl_n8mlQLI",
	identityToolkitUrl: "https://identitytoolkit.googleapis.com",
	secureTokenUrl: "https://securetoken.googleapis.com",
	firestoreUrl: "https://firestore.googleapis.com",
	frontendBaseUrl: "https://lingogram.ai",
	source: "youtube-extension"
};
t.env;
//#endregion
//#region ../../packages/shared/src/auth/storage.ts
var n = {
	idToken: "auth.idToken",
	refreshToken: "auth.refreshToken",
	expiresAt: "auth.expiresAt",
	email: "auth.email",
	uid: "auth.uid",
	inboxCount: "inbox.count",
	savedWordCount: "rate.savedWordCount",
	ratePromptShown: "rate.promptShown"
};
async function r() {
	let e = await chrome.storage.local.get([
		n.idToken,
		n.refreshToken,
		n.expiresAt,
		n.email,
		n.uid
	]), t = e[n.idToken], r = e[n.uid];
	return !t || !r ? null : {
		idToken: String(t),
		refreshToken: String(e[n.refreshToken] ?? ""),
		expiresAt: Number(e[n.expiresAt] ?? 0),
		email: String(e[n.email] ?? ""),
		uid: String(r)
	};
}
async function i(e) {
	await chrome.storage.local.set({
		[n.idToken]: e.idToken,
		[n.refreshToken]: e.refreshToken,
		[n.expiresAt]: e.expiresAt,
		[n.email]: e.email,
		[n.uid]: e.uid
	});
}
async function a() {
	await chrome.storage.local.remove([
		n.idToken,
		n.refreshToken,
		n.expiresAt,
		n.email,
		n.uid
	]);
}
async function o() {
	return (await chrome.storage.local.get(n.inboxCount))[n.inboxCount] ?? 0;
}
async function s() {
	let e = await o() + 1;
	return await chrome.storage.local.set({ [n.inboxCount]: e }), e;
}
async function c() {
	return (await chrome.storage.local.get(n.savedWordCount))[n.savedWordCount] ?? 0;
}
async function l() {
	let e = await c() + 1;
	return await chrome.storage.local.set({ [n.savedWordCount]: e }), e;
}
async function u() {
	return (await chrome.storage.local.get(n.ratePromptShown))[n.ratePromptShown] === !0;
}
async function d() {
	await chrome.storage.local.set({ [n.ratePromptShown]: !0 });
}
var f = 600 * 1e3, p = {
	value: "auth.pendingNonce",
	issuedAt: "auth.pendingNonceAt"
};
async function m(e) {
	await chrome.storage.session.set({
		[p.value]: e,
		[p.issuedAt]: Date.now()
	});
}
async function h(e) {
	let t = await chrome.storage.session.get([p.value, p.issuedAt]), n = t[p.value], r = t[p.issuedAt], i = typeof n == "string" ? n : "", a = typeof r == "number" ? r : 0;
	return !i || !e || Date.now() - a > f ? !1 : i === e;
}
async function g() {
	await chrome.storage.session.remove([p.value, p.issuedAt]);
}
//#endregion
//#region ../../packages/shared/src/auth/firebaseRest.ts
function _(e) {
	let t = parseInt(e, 10);
	return Date.now() + t * 1e3;
}
async function v(e, t) {
	let n = `${e.secureTokenUrl}/v1/token?key=${encodeURIComponent(e.apiKey)}`, r = `grant_type=refresh_token&refresh_token=${encodeURIComponent(t)}`, i = await fetch(n, {
		method: "POST",
		headers: { "Content-Type": "application/x-www-form-urlencoded" },
		body: r
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.id_token,
		refreshToken: a.refresh_token,
		expiresAt: _(a.expires_in),
		uid: a.user_id
	};
}
async function y(e, t, n) {
	let r = `${e.identityToolkitUrl}/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(e.apiKey)}`, i = await fetch(r, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			token: t,
			returnSecureToken: !0
		})
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.idToken,
		refreshToken: a.refreshToken,
		expiresAt: _(a.expiresIn),
		uid: a.localId || n
	};
}
//#endregion
//#region ../../packages/shared/src/auth/firestoreRest.ts
var b = 500, x = 256, S = 2048, C = 6e4;
async function w(e) {
	let t = await r();
	if (!t) throw Error("Not signed in");
	if (t.expiresAt > Date.now() + C) return t;
	let n = await v(e, t.refreshToken), a = {
		...t,
		...n
	};
	return await i(a), a;
}
function T() {
	let e = /* @__PURE__ */ new Date();
	return e.getUTCFullYear() * 1e4 + (e.getUTCMonth() + 1) * 100 + e.getUTCDate();
}
var E = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
function D() {
	let e = new Uint8Array(20);
	crypto.getRandomValues(e);
	let t = "";
	for (let n = 0; n < 20; n++) t += E[e[n] % 62];
	return t;
}
function O(e, t) {
	return `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents/inbox/${encodeURIComponent(t)}`;
}
async function k(e, t, n) {
	let r = await fetch(O(e, n), { headers: { Authorization: `Bearer ${t}` } });
	if (r.status === 404) return null;
	if (r.status === 401) throw Error("Firestore sentinel 401");
	if (!r.ok) {
		let e = await r.text().catch(() => "");
		throw Error(`Firestore GET sentinel ${r.status}: ${e || r.statusText}`);
	}
	let i = (await r.json()).fields ?? {};
	return {
		dailyCount: parseInt(i.dailyCount?.integerValue ?? "0", 10),
		dayBucket: parseInt(i.dayBucket?.integerValue ?? "0", 10)
	};
}
function A(e, t, n, r) {
	let i = T(), a = r && r.dayBucket === i ? r.dailyCount + 1 : 1;
	if (a > b) throw Error(`Daily limit of ${b} words reached. Try again tomorrow.`);
	let o = D(), s = `projects/${e.projectId}/databases/(default)/documents/inbox/${t}`, c = `${s}/words/${o}`, l = {
		term: { stringValue: n.term },
		source: { stringValue: e.source },
		processed: { booleanValue: !1 }
	};
	return n.context && (l.context = { stringValue: n.context }), {
		writes: [{
			update: {
				name: c,
				fields: l
			},
			currentDocument: { exists: !1 },
			updateTransforms: [{
				fieldPath: "addedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}, {
			update: {
				name: s,
				fields: {
					dailyCount: { integerValue: String(a) },
					dayBucket: { integerValue: String(i) }
				}
			},
			updateTransforms: [{
				fieldPath: "lastAddedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}],
		wordId: o,
		documentPath: c
	};
}
function j(e) {
	return new TextEncoder().encode(e).length;
}
function M(e, t) {
	let n = new TextEncoder();
	if (n.encode(e).length <= t) return e;
	let r = 0, i = e.length;
	for (; r < i;) {
		let a = r + i + 1 >>> 1;
		n.encode(e.slice(0, a)).length <= t ? r = a : i = a - 1;
	}
	for (; r > 0;) {
		let t = e.charCodeAt(r - 1);
		if (t >= 55296 && t <= 56319) r--;
		else break;
	}
	return e.slice(0, r);
}
async function N(e, t) {
	let n = await w(e), r = `${n.uid}_${T()}`, i = [{
		update: {
			name: `projects/${e.projectId}/databases/(default)/documents/diagnostics/${r}`,
			fields: {
				kind: { stringValue: "no_subs_after_retry" },
				site: { stringValue: M(t.site, 100) },
				videoRef: { stringValue: M(t.videoRef, 500) },
				version: { stringValue: M(t.version, 32) },
				locale: { stringValue: M(t.locale, 16) },
				learning: { stringValue: M(t.learning, 16) },
				native: { stringValue: M(t.native, 16) },
				source: { stringValue: e.source }
			}
		},
		currentDocument: { exists: !1 },
		updateTransforms: [{
			fieldPath: "addedAt",
			setToServerValue: "REQUEST_TIME"
		}]
	}], a = await fetch(`${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${n.idToken}`
		},
		body: JSON.stringify({ writes: i })
	});
	if (!a.ok) {
		let e = await a.text().catch(() => "");
		throw Error(`Firestore diagnostics commit ${a.status}: ${e || a.statusText}`);
	}
}
async function P(e, t) {
	let n = j(t.term);
	if (n === 0 || n > x) throw Error(`term must be 1..${x} bytes (UTF-8)`);
	t.context && j(t.context) > S && (t = {
		...t,
		context: M(t.context, S)
	});
	let r = await w(e), a;
	try {
		a = await k(e, r.idToken, r.uid);
	} catch (t) {
		if (t instanceof Error && t.message === "Firestore sentinel 401") {
			let t = await v(e, r.refreshToken);
			r = {
				...r,
				...t
			}, await i(r), a = await k(e, r.idToken, r.uid);
		} else throw t;
	}
	let { writes: o, wordId: s, documentPath: c } = A(e, r.uid, t, a), l = `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, u = JSON.stringify({ writes: o }), d = await fetch(l, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${r.idToken}`
		},
		body: u
	});
	if (d.status === 401) {
		let t = await v(e, r.refreshToken);
		r = {
			...r,
			...t
		}, await i(r), d = await fetch(l, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${r.idToken}`
			},
			body: u
		});
	}
	if (!d.ok) {
		let e = await d.text().catch(() => "");
		throw Error(`Firestore commit ${d.status}: ${e || d.statusText}`);
	}
	return await d.json(), {
		wordId: s,
		documentPath: c
	};
}
//#endregion
//#region ../../packages/shared/src/auth/background.ts
var F = new Set([
	"AUTH_STATUS",
	"AUTH_SIGN_IN_VIA_LINGOGRAM",
	"AUTH_SIGN_OUT",
	"OPEN_LINGOGRAM",
	"ADD_WORD",
	"REPORT_NO_SUBS"
]);
function I(e) {
	return typeof e == "string" && F.has(e);
}
function L() {
	try {
		chrome.action?.setBadgeText({ text: "!" }), chrome.action?.setBadgeBackgroundColor?.({ color: "#dc2626" });
	} catch {}
}
function R() {
	try {
		chrome.action?.setBadgeText({ text: "" });
	} catch {}
}
function z(e) {
	if (!(e instanceof Error)) return !1;
	let t = e.message;
	return t.includes("Not signed in") || t.includes("Firebase REST 400") || t.includes("Firebase REST 401") || t.includes("Firebase REST 403") || t.includes("Firestore commit 401") || t.includes("Firestore commit 403") || t.includes("Firestore sentinel 401") || t.includes("INVALID_REFRESH_TOKEN") || t.includes("TOKEN_EXPIRED");
}
async function B(e) {
	switch (e.action) {
		case "AUTH_STATUS": {
			let e = await r(), t = await o();
			return e ? {
				signedIn: !0,
				email: e.email,
				uid: e.uid,
				inboxCount: t
			} : {
				signedIn: !1,
				inboxCount: t
			};
		}
		case "AUTH_SIGN_IN_VIA_LINGOGRAM": {
			let e = chrome.runtime.id, n = crypto.randomUUID();
			await m(n);
			let r = `${t.frontendBaseUrl}/extension-auth?ext=${encodeURIComponent(e)}&nonce=${encodeURIComponent(n)}`;
			return await chrome.tabs.create({ url: r }), { ok: !0 };
		}
		case "OPEN_LINGOGRAM": return await chrome.tabs.create({ url: t.frontendBaseUrl }), { ok: !0 };
		case "AUTH_SIGN_OUT": return await a(), R(), { ok: !0 };
		case "ADD_WORD": {
			let n = String(e.term ?? "").trim(), r = typeof e.context == "string" ? e.context : "";
			if (!n) throw Error("term required");
			let i = {
				term: n,
				context: r
			};
			try {
				let e = await P(t, i), n = await s(), r = await l(), a = !1;
				return r >= 30 && !await u() && (await d(), a = !0), {
					ok: !0,
					wordId: e.wordId,
					inboxCount: n,
					promptRate: a
				};
			} catch (e) {
				throw z(e) && (await a(), L()), e;
			}
		}
		case "REPORT_NO_SUBS": {
			let n = String(e.videoRef ?? "");
			if (!n) return { ok: !1 };
			try {
				return await N(t, {
					site: String(e.site ?? ""),
					videoRef: n,
					version: String(e.version ?? ""),
					locale: String(e.locale ?? ""),
					learning: String(e.learning ?? ""),
					native: String(e.native ?? "")
				}), { ok: !0 };
			} catch {
				return { ok: !1 };
			}
		}
		default: throw Error(`unknown action: ${e.action}`);
	}
}
function V(e) {
	let t = /* @__PURE__ */ new Set();
	try {
		let n = new URL(e);
		if (t.add(n.origin), n.hostname.endsWith(".web.app")) {
			let e = n.hostname.replace(/\.web\.app$/, ".firebaseapp.com");
			t.add(`${n.protocol}//${e}`);
		} else if (n.hostname.endsWith(".firebaseapp.com")) {
			let e = n.hostname.replace(/\.firebaseapp\.com$/, ".web.app");
			t.add(`${n.protocol}//${e}`);
		}
	} catch {}
	return t;
}
var H = V(t.frontendBaseUrl);
function U(e) {
	let t = e.origin ?? (e.url ? new URL(e.url).origin : void 0);
	return !!t && H.has(t);
}
function W() {
	chrome.runtime.onMessageExternal.addListener((e, n, r) => {
		if (!U(n)) return r({
			ok: !1,
			error: "unauthorized origin"
		}), !1;
		if (e?.type !== "lingogram-extension-auth") return r({
			ok: !1,
			error: "unknown message type"
		}), !1;
		let a = e.payload ?? {}, o = typeof a.customToken == "string" ? a.customToken : "", s = typeof a.email == "string" ? a.email : "", c = typeof a.uid == "string" ? a.uid : "", l = typeof a.nonce == "string" ? a.nonce : "";
		return !o || !c ? (r({
			ok: !1,
			error: "customToken and uid required"
		}), !1) : ((async () => {
			if (!await h(l)) {
				r({
					ok: !1,
					error: "invalid or expired auth challenge — open the extension popup and start the sign-in flow from there"
				});
				return;
			}
			try {
				let e = await y(t, o, c);
				await i({
					idToken: e.idToken,
					refreshToken: e.refreshToken,
					expiresAt: e.expiresAt,
					email: s,
					uid: e.uid
				}), await g(), R(), r({ ok: !0 });
			} catch (e) {
				r({
					ok: !1,
					error: String(e instanceof Error ? e.message : e)
				});
			}
		})(), !0);
	});
}
function G() {
	chrome.runtime.onMessage.addListener((e, t, n) => I(e?.action) ? ((async () => {
		try {
			n(await B(e));
		} catch (e) {
			console.error("Background auth handler error:", e), n({
				ok: !1,
				error: String(e instanceof Error ? e.message : e)
			});
		}
	})(), !0) : !1);
}
async function K() {
	let e = await r();
	e && !e.refreshToken && (await a(), L());
}
function q() {
	G(), W(), K();
}
chrome.runtime.onInstalled.addListener(() => {
	console.log("[YT-VTT bg] installed");
}), q();
//#endregion
