//#region ../../packages/shared/src/auth/config.ts
var e = {
	env: "prod",
	projectId: "project-51896e3c-eb11-40-4279f",
	apiKey: "AIzaSyDeUTNMiBpHeP1Ay52IA_S0jNQjTVny68s",
	identityToolkitUrl: "https://identitytoolkit.googleapis.com",
	secureTokenUrl: "https://securetoken.googleapis.com",
	firestoreUrl: "https://firestore.googleapis.com",
	frontendBaseUrl: "https://lingogram-app.web.app",
	source: "rezka-extension"
};
e.env;
//#endregion
//#region ../../packages/shared/src/auth/storage.ts
var t = {
	idToken: "auth.idToken",
	refreshToken: "auth.refreshToken",
	expiresAt: "auth.expiresAt",
	email: "auth.email",
	uid: "auth.uid",
	inboxCount: "inbox.count"
};
async function n() {
	let e = await chrome.storage.local.get([
		t.idToken,
		t.refreshToken,
		t.expiresAt,
		t.email,
		t.uid
	]), n = e[t.idToken], r = e[t.uid];
	return !n || !r ? null : {
		idToken: String(n),
		refreshToken: String(e[t.refreshToken] ?? ""),
		expiresAt: Number(e[t.expiresAt] ?? 0),
		email: String(e[t.email] ?? ""),
		uid: String(r)
	};
}
async function r(e) {
	await chrome.storage.local.set({
		[t.idToken]: e.idToken,
		[t.refreshToken]: e.refreshToken,
		[t.expiresAt]: e.expiresAt,
		[t.email]: e.email,
		[t.uid]: e.uid
	});
}
async function i() {
	await chrome.storage.local.remove([
		t.idToken,
		t.refreshToken,
		t.expiresAt,
		t.email,
		t.uid
	]);
}
async function a() {
	return (await chrome.storage.local.get(t.inboxCount))[t.inboxCount] ?? 0;
}
async function o() {
	let e = await a() + 1;
	return await chrome.storage.local.set({ [t.inboxCount]: e }), e;
}
//#endregion
//#region ../../packages/shared/src/auth/firebaseRest.ts
function s(e) {
	let t = parseInt(e, 10);
	return Date.now() + t * 1e3;
}
async function c(e, t, n = "application/json") {
	let r = {
		method: "POST",
		headers: { "Content-Type": n },
		body: typeof t == "string" ? t : JSON.stringify(t)
	}, i = await fetch(e, r);
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	return i.json();
}
async function l(e, t, n) {
	let r = await c(`${e.identityToolkitUrl}/v1/accounts:signInWithPassword?key=${encodeURIComponent(e.apiKey)}`, {
		email: t,
		password: n,
		returnSecureToken: !0
	});
	return {
		idToken: r.idToken,
		refreshToken: r.refreshToken,
		expiresAt: s(r.expiresIn),
		email: r.email,
		uid: r.localId
	};
}
async function u(e, t) {
	let n = await c(`${e.secureTokenUrl}/v1/token?key=${encodeURIComponent(e.apiKey)}`, `grant_type=refresh_token&refresh_token=${encodeURIComponent(t)}`, "application/x-www-form-urlencoded");
	return {
		idToken: n.id_token,
		refreshToken: n.refresh_token,
		expiresAt: s(n.expires_in),
		uid: n.user_id
	};
}
//#endregion
//#region ../../packages/shared/src/auth/firestoreRest.ts
var d = 500, f = 256, p = 2048, m = 2048, h = 512, g = 6e4;
async function _(e) {
	let t = await n();
	if (!t) throw Error("Not signed in");
	if (t.expiresAt > Date.now() + g) return t;
	let i = await u(e, t.refreshToken), a = {
		...t,
		...i
	};
	return await r(a), a;
}
function v() {
	let e = /* @__PURE__ */ new Date();
	return e.getUTCFullYear() * 1e4 + (e.getUTCMonth() + 1) * 100 + e.getUTCDate();
}
var y = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
function b() {
	let e = new Uint8Array(20);
	crypto.getRandomValues(e);
	let t = "";
	for (let n = 0; n < 20; n++) t += y[e[n] % 62];
	return t;
}
function x(e, t) {
	return `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents/inbox/${encodeURIComponent(t)}`;
}
async function S(e, t, n) {
	let r = await fetch(x(e, n), { headers: { Authorization: `Bearer ${t}` } });
	if (r.status === 404) return null;
	if (r.status === 401) throw Error("Firestore sentinel 401");
	if (!r.ok) {
		let e = await r.text().catch(() => "");
		throw Error(`Firestore GET sentinel ${r.status}: ${e || r.statusText}`);
	}
	let i = (await r.json()).fields ?? {};
	return {
		dailyCount: parseInt(i.dailyCount?.integerValue ?? "0", 10),
		dayBucket: parseInt(i.dayBucket?.integerValue ?? "0", 10)
	};
}
function C(e, t, n, r) {
	let i = v(), a = r && r.dayBucket === i ? r.dailyCount + 1 : 1;
	if (a > d) throw Error(`Daily limit of ${d} words reached. Try again tomorrow.`);
	let o = b(), s = `projects/${e.projectId}/databases/(default)/documents/inbox/${t}`, c = `${s}/words/${o}`, l = {
		term: { stringValue: n.term },
		source: { stringValue: e.source },
		sourceUrl: { stringValue: n.sourceUrl },
		processed: { booleanValue: !1 }
	};
	return n.context && (l.context = { stringValue: n.context }), n.title && (l.title = { stringValue: n.title }), {
		writes: [{
			update: {
				name: c,
				fields: l
			},
			currentDocument: { exists: !1 },
			updateTransforms: [{
				fieldPath: "addedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}, {
			update: {
				name: s,
				fields: {
					dailyCount: { integerValue: String(a) },
					dayBucket: { integerValue: String(i) }
				}
			},
			updateTransforms: [{
				fieldPath: "lastAddedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}],
		wordId: o,
		documentPath: c
	};
}
function w(e) {
	return new TextEncoder().encode(e).length;
}
function T(e, t) {
	let n = new TextEncoder();
	if (n.encode(e).length <= t) return e;
	let r = 0, i = e.length;
	for (; r < i;) {
		let a = r + i + 1 >>> 1;
		n.encode(e.slice(0, a)).length <= t ? r = a : i = a - 1;
	}
	for (; r > 0;) {
		let t = e.charCodeAt(r - 1);
		if (t >= 55296 && t <= 56319) r--;
		else break;
	}
	return e.slice(0, r);
}
async function E(e, t) {
	let n = w(t.term);
	if (n === 0 || n > f) throw Error(`term must be 1..${f} bytes (UTF-8)`);
	if (w(t.sourceUrl) > p) throw Error(`sourceUrl exceeds ${p} bytes`);
	t.context && w(t.context) > m && (t = {
		...t,
		context: T(t.context, m)
	}), t.title && w(t.title) > h && (t = {
		...t,
		title: T(t.title, h)
	});
	let i = await _(e), a;
	try {
		a = await S(e, i.idToken, i.uid);
	} catch (t) {
		if (t instanceof Error && t.message === "Firestore sentinel 401") {
			let t = await u(e, i.refreshToken);
			i = {
				...i,
				...t
			}, await r(i), a = await S(e, i.idToken, i.uid);
		} else throw t;
	}
	let { writes: o, wordId: s, documentPath: c } = C(e, i.uid, t, a), l = `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, d = JSON.stringify({ writes: o }), g = await fetch(l, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${i.idToken}`
		},
		body: d
	});
	if (g.status === 401) {
		let t = await u(e, i.refreshToken);
		i = {
			...i,
			...t
		}, await r(i), g = await fetch(l, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${i.idToken}`
			},
			body: d
		});
	}
	if (!g.ok) {
		let e = await g.text().catch(() => "");
		throw Error(`Firestore commit ${g.status}: ${e || g.statusText}`);
	}
	return await g.json(), {
		wordId: s,
		documentPath: c
	};
}
//#endregion
//#region ../../packages/shared/src/auth/background.ts
var D = new Set([
	"AUTH_STATUS",
	"AUTH_SIGN_IN_PASSWORD",
	"AUTH_SIGN_IN_VIA_LINGOGRAM",
	"AUTH_SIGN_OUT",
	"ADD_WORD"
]);
function O(e) {
	return typeof e == "string" && D.has(e);
}
async function k(t) {
	switch (t.action) {
		case "AUTH_STATUS": {
			let e = await n(), t = await a();
			return e ? {
				signedIn: !0,
				email: e.email,
				uid: e.uid,
				inboxCount: t
			} : {
				signedIn: !1,
				inboxCount: t
			};
		}
		case "AUTH_SIGN_IN_PASSWORD": {
			let n = String(t.email ?? ""), i = String(t.password ?? "");
			if (!n || !i) throw Error("email and password required");
			return await r(await l(e, n, i)), { ok: !0 };
		}
		case "AUTH_SIGN_IN_VIA_LINGOGRAM": {
			let t = chrome.runtime.id, n = `${e.frontendBaseUrl}/extension-auth?ext=${encodeURIComponent(t)}`;
			return await chrome.tabs.create({ url: n }), { ok: !0 };
		}
		case "AUTH_SIGN_OUT": return await i(), { ok: !0 };
		case "ADD_WORD": {
			let n = String(t.term ?? "").trim(), r = String(t.sourceUrl ?? ""), i = typeof t.context == "string" ? t.context : "", a = typeof t.title == "string" ? t.title : "";
			if (!n) throw Error("term required");
			let s = {
				term: n,
				sourceUrl: r,
				context: i,
				title: a
			};
			try {
				let t = await E(e, s), n = await o();
				return {
					ok: !0,
					wordId: t.wordId,
					inboxCount: n
				};
			} catch (t) {
				if (!await R()) throw t;
				await z();
				let n = await E(e, s), r = await o();
				return {
					ok: !0,
					wordId: n.wordId,
					inboxCount: r
				};
			}
		}
		default: throw Error(`unknown action: ${t.action}`);
	}
}
function A(e) {
	let t = /* @__PURE__ */ new Set();
	try {
		let n = new URL(e);
		if (t.add(n.origin), n.hostname.endsWith(".web.app")) {
			let e = n.hostname.replace(/\.web\.app$/, ".firebaseapp.com");
			t.add(`${n.protocol}//${e}`);
		} else if (n.hostname.endsWith(".firebaseapp.com")) {
			let e = n.hostname.replace(/\.firebaseapp\.com$/, ".web.app");
			t.add(`${n.protocol}//${e}`);
		}
	} catch {}
	return t;
}
var j = A(e.frontendBaseUrl);
function M(e) {
	let t = e.origin ?? (e.url ? new URL(e.url).origin : void 0);
	return !!t && j.has(t);
}
var N = /* @__PURE__ */ new Set(), P = null, F = null, I = 3e4, L = 6e4;
async function R() {
	let e = await n();
	return !e || e.refreshToken ? !1 : e.expiresAt <= Date.now() + L;
}
async function z() {
	if (P) return P;
	P = (async () => {
		let t = `${e.frontendBaseUrl}/extension-auth?ext=${encodeURIComponent(chrome.runtime.id)}&silent=1`, n = (await chrome.tabs.create({
			url: t,
			active: !1
		})).id;
		if (n === void 0) throw Error("silent reauth: tabs.create returned no id");
		N.add(n);
		try {
			await new Promise((e, t) => {
				F = {
					resolve: e,
					reject: t
				}, setTimeout(() => {
					if (F) {
						let e = F;
						F = null, e.reject(/* @__PURE__ */ Error("silent reauth timed out — sign in via the Lingogram badge"));
					}
				}, I);
			});
		} finally {
			N.delete(n);
			try {
				await chrome.tabs.remove(n);
			} catch {}
		}
	})();
	try {
		await P;
	} catch (e) {
		throw await i(), e;
	} finally {
		P = null;
	}
}
function B() {
	chrome.runtime.onMessageExternal.addListener((e, t, n) => {
		if (!M(t)) return n({
			ok: !1,
			error: "unauthorized origin"
		}), !1;
		if (e?.type !== "lingogram-extension-auth") return n({
			ok: !1,
			error: "unknown message type"
		}), !1;
		let i = e.payload ?? {}, a = typeof i.idToken == "string" ? i.idToken : "", o = typeof i.refreshToken == "string" ? i.refreshToken : "", s = typeof i.expiresAt == "number" ? i.expiresAt : 0, c = typeof i.email == "string" ? i.email : "", l = typeof i.uid == "string" ? i.uid : "";
		if (!a || !l) return n({
			ok: !1,
			error: "idToken and uid required"
		}), !1;
		let u = t.tab?.id, d = typeof i.silent == "boolean" && i.silent || u !== void 0 && N.has(u);
		return (async () => {
			try {
				if (await r({
					idToken: a,
					refreshToken: o,
					expiresAt: s,
					email: c,
					uid: l
				}), console.log("[Lingogram] external auth handoff accepted for", c || l), n({ ok: !0 }), d && (F?.resolve(), F = null, u !== void 0)) {
					N.delete(u);
					try {
						await chrome.tabs.remove(u);
					} catch {}
				}
			} catch (e) {
				n({
					ok: !1,
					error: String(e instanceof Error ? e.message : e)
				}), d && (F?.reject(e instanceof Error ? e : Error(String(e))), F = null);
			}
		})(), !0;
	});
}
function V() {
	chrome.runtime.onMessage.addListener((e, t, n) => O(e?.action) ? ((async () => {
		try {
			n(await k(e));
		} catch (e) {
			console.error("Background auth handler error:", e), n({
				ok: !1,
				error: String(e instanceof Error ? e.message : e)
			});
		}
	})(), !0) : !1);
}
function H() {
	V(), B();
}
//#endregion
//#region src/background/background.ts
async function U(e, t = 3, n = 1e3) {
	for (let r = 0; r < t; r++) try {
		let t = await fetch(e);
		if (!t.ok) throw Error(`HTTP error! status: ${t.status}`);
		return await t.text();
	} catch (i) {
		if (console.warn(`Fetch attempt ${r + 1} failed for ${e}:`, i.message), r < t - 1) await new Promise((e) => setTimeout(e, n));
		else throw i;
	}
	throw Error(`Failed to fetch ${e} after ${t} attempts`);
}
H(), chrome.runtime.onMessage.addListener((e, t) => e.action === "TIME_UPDATE" || e.action === "SEEK_VIDEO" || e.action === "VTT_LOADED" ? (t.tab && t.tab.id && chrome.tabs.sendMessage(t.tab.id, e), !1) : (e.action === "FETCH_VTT" && U(e.url).then((n) => {
	t.tab && t.tab.id && chrome.tabs.sendMessage(t.tab.id, {
		action: "VTT_LOADED",
		payload: n,
		url: e.url
	});
}).catch((e) => {
	console.error("Background: Failed to fetch VTT:", e);
}), !1));
//#endregion
export { U as fetchWithRetry };
