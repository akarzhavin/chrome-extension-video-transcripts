//#region ../../packages/shared/src/auth/config.ts
var e = {
	env: "prod",
	projectId: "lingogram-prod",
	apiKey: "AIzaSyCHQt2zwkO-x8qm7wM5IwWAWrl_n8mlQLI",
	identityToolkitUrl: "https://identitytoolkit.googleapis.com",
	secureTokenUrl: "https://securetoken.googleapis.com",
	firestoreUrl: "https://firestore.googleapis.com",
	frontendBaseUrl: "https://lingogram.ai",
	source: "rezka-extension"
};
e.env;
//#endregion
//#region ../../packages/shared/src/auth/storage.ts
var t = {
	idToken: "auth.idToken",
	refreshToken: "auth.refreshToken",
	expiresAt: "auth.expiresAt",
	email: "auth.email",
	uid: "auth.uid",
	inboxCount: "inbox.count"
};
async function n() {
	let e = await chrome.storage.local.get([
		t.idToken,
		t.refreshToken,
		t.expiresAt,
		t.email,
		t.uid
	]), n = e[t.idToken], r = e[t.uid];
	return !n || !r ? null : {
		idToken: String(n),
		refreshToken: String(e[t.refreshToken] ?? ""),
		expiresAt: Number(e[t.expiresAt] ?? 0),
		email: String(e[t.email] ?? ""),
		uid: String(r)
	};
}
async function r(e) {
	await chrome.storage.local.set({
		[t.idToken]: e.idToken,
		[t.refreshToken]: e.refreshToken,
		[t.expiresAt]: e.expiresAt,
		[t.email]: e.email,
		[t.uid]: e.uid
	});
}
async function i() {
	await chrome.storage.local.remove([
		t.idToken,
		t.refreshToken,
		t.expiresAt,
		t.email,
		t.uid
	]);
}
async function a() {
	return (await chrome.storage.local.get(t.inboxCount))[t.inboxCount] ?? 0;
}
async function o() {
	let e = await a() + 1;
	return await chrome.storage.local.set({ [t.inboxCount]: e }), e;
}
var s = 600 * 1e3, c = {
	value: "auth.pendingNonce",
	issuedAt: "auth.pendingNonceAt"
};
async function l(e) {
	await chrome.storage.session.set({
		[c.value]: e,
		[c.issuedAt]: Date.now()
	});
}
async function u(e) {
	let t = await chrome.storage.session.get([c.value, c.issuedAt]), n = t[c.value], r = t[c.issuedAt], i = typeof n == "string" ? n : "", a = typeof r == "number" ? r : 0;
	return !i || !e || Date.now() - a > s ? !1 : i === e;
}
async function d() {
	await chrome.storage.session.remove([c.value, c.issuedAt]);
}
//#endregion
//#region ../../packages/shared/src/auth/firebaseRest.ts
function f(e) {
	let t = parseInt(e, 10);
	return Date.now() + t * 1e3;
}
async function p(e, t) {
	let n = `${e.secureTokenUrl}/v1/token?key=${encodeURIComponent(e.apiKey)}`, r = `grant_type=refresh_token&refresh_token=${encodeURIComponent(t)}`, i = await fetch(n, {
		method: "POST",
		headers: { "Content-Type": "application/x-www-form-urlencoded" },
		body: r
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.id_token,
		refreshToken: a.refresh_token,
		expiresAt: f(a.expires_in),
		uid: a.user_id
	};
}
async function m(e, t, n) {
	let r = `${e.identityToolkitUrl}/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(e.apiKey)}`, i = await fetch(r, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			token: t,
			returnSecureToken: !0
		})
	});
	if (!i.ok) {
		let e = await i.text().catch(() => "");
		throw Error(`Firebase REST ${i.status}: ${e || i.statusText}`);
	}
	let a = await i.json();
	return {
		idToken: a.idToken,
		refreshToken: a.refreshToken,
		expiresAt: f(a.expiresIn),
		uid: a.localId || n
	};
}
//#endregion
//#region ../../packages/shared/src/auth/firestoreRest.ts
var h = 500, g = 256, _ = 2048, v = 6e4;
async function y(e) {
	let t = await n();
	if (!t) throw Error("Not signed in");
	if (t.expiresAt > Date.now() + v) return t;
	let i = await p(e, t.refreshToken), a = {
		...t,
		...i
	};
	return await r(a), a;
}
function b() {
	let e = /* @__PURE__ */ new Date();
	return e.getUTCFullYear() * 1e4 + (e.getUTCMonth() + 1) * 100 + e.getUTCDate();
}
var x = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
function S() {
	let e = new Uint8Array(20);
	crypto.getRandomValues(e);
	let t = "";
	for (let n = 0; n < 20; n++) t += x[e[n] % 62];
	return t;
}
function C(e, t) {
	return `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents/inbox/${encodeURIComponent(t)}`;
}
async function w(e, t, n) {
	let r = await fetch(C(e, n), { headers: { Authorization: `Bearer ${t}` } });
	if (r.status === 404) return null;
	if (r.status === 401) throw Error("Firestore sentinel 401");
	if (!r.ok) {
		let e = await r.text().catch(() => "");
		throw Error(`Firestore GET sentinel ${r.status}: ${e || r.statusText}`);
	}
	let i = (await r.json()).fields ?? {};
	return {
		dailyCount: parseInt(i.dailyCount?.integerValue ?? "0", 10),
		dayBucket: parseInt(i.dayBucket?.integerValue ?? "0", 10)
	};
}
function T(e, t, n, r) {
	let i = b(), a = r && r.dayBucket === i ? r.dailyCount + 1 : 1;
	if (a > h) throw Error(`Daily limit of ${h} words reached. Try again tomorrow.`);
	let o = S(), s = `projects/${e.projectId}/databases/(default)/documents/inbox/${t}`, c = `${s}/words/${o}`, l = {
		term: { stringValue: n.term },
		source: { stringValue: e.source },
		processed: { booleanValue: !1 }
	};
	return n.context && (l.context = { stringValue: n.context }), {
		writes: [{
			update: {
				name: c,
				fields: l
			},
			currentDocument: { exists: !1 },
			updateTransforms: [{
				fieldPath: "addedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}, {
			update: {
				name: s,
				fields: {
					dailyCount: { integerValue: String(a) },
					dayBucket: { integerValue: String(i) }
				}
			},
			updateTransforms: [{
				fieldPath: "lastAddedAt",
				setToServerValue: "REQUEST_TIME"
			}]
		}],
		wordId: o,
		documentPath: c
	};
}
function E(e) {
	return new TextEncoder().encode(e).length;
}
function D(e, t) {
	let n = new TextEncoder();
	if (n.encode(e).length <= t) return e;
	let r = 0, i = e.length;
	for (; r < i;) {
		let a = r + i + 1 >>> 1;
		n.encode(e.slice(0, a)).length <= t ? r = a : i = a - 1;
	}
	for (; r > 0;) {
		let t = e.charCodeAt(r - 1);
		if (t >= 55296 && t <= 56319) r--;
		else break;
	}
	return e.slice(0, r);
}
async function O(e, t) {
	let n = E(t.term);
	if (n === 0 || n > g) throw Error(`term must be 1..${g} bytes (UTF-8)`);
	t.context && E(t.context) > _ && (t = {
		...t,
		context: D(t.context, _)
	});
	let i = await y(e), a;
	try {
		a = await w(e, i.idToken, i.uid);
	} catch (t) {
		if (t instanceof Error && t.message === "Firestore sentinel 401") {
			let t = await p(e, i.refreshToken);
			i = {
				...i,
				...t
			}, await r(i), a = await w(e, i.idToken, i.uid);
		} else throw t;
	}
	let { writes: o, wordId: s, documentPath: c } = T(e, i.uid, t, a), l = `${e.firestoreUrl}/v1/projects/${e.projectId}/databases/(default)/documents:commit`, u = JSON.stringify({ writes: o }), d = await fetch(l, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${i.idToken}`
		},
		body: u
	});
	if (d.status === 401) {
		let t = await p(e, i.refreshToken);
		i = {
			...i,
			...t
		}, await r(i), d = await fetch(l, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${i.idToken}`
			},
			body: u
		});
	}
	if (!d.ok) {
		let e = await d.text().catch(() => "");
		throw Error(`Firestore commit ${d.status}: ${e || d.statusText}`);
	}
	return await d.json(), {
		wordId: s,
		documentPath: c
	};
}
//#endregion
//#region ../../packages/shared/src/auth/background.ts
var k = new Set([
	"AUTH_STATUS",
	"AUTH_SIGN_IN_VIA_LINGOGRAM",
	"AUTH_SIGN_OUT",
	"ADD_WORD"
]);
function A(e) {
	return typeof e == "string" && k.has(e);
}
function j() {
	try {
		chrome.action?.setBadgeText({ text: "!" }), chrome.action?.setBadgeBackgroundColor?.({ color: "#dc2626" });
	} catch {}
}
function M() {
	try {
		chrome.action?.setBadgeText({ text: "" });
	} catch {}
}
function N(e) {
	if (!(e instanceof Error)) return !1;
	let t = e.message;
	return t.includes("Not signed in") || t.includes("Firebase REST 400") || t.includes("Firebase REST 401") || t.includes("Firebase REST 403") || t.includes("Firestore commit 401") || t.includes("Firestore commit 403") || t.includes("Firestore sentinel 401") || t.includes("INVALID_REFRESH_TOKEN") || t.includes("TOKEN_EXPIRED");
}
async function P(t) {
	switch (t.action) {
		case "AUTH_STATUS": {
			let e = await n(), t = await a();
			return e ? {
				signedIn: !0,
				email: e.email,
				uid: e.uid,
				inboxCount: t
			} : {
				signedIn: !1,
				inboxCount: t
			};
		}
		case "AUTH_SIGN_IN_VIA_LINGOGRAM": {
			let t = chrome.runtime.id, n = crypto.randomUUID();
			await l(n);
			let r = `${e.frontendBaseUrl}/extension-auth?ext=${encodeURIComponent(t)}&nonce=${encodeURIComponent(n)}`;
			return await chrome.tabs.create({ url: r }), { ok: !0 };
		}
		case "AUTH_SIGN_OUT": return await i(), M(), { ok: !0 };
		case "ADD_WORD": {
			let n = String(t.term ?? "").trim(), r = typeof t.context == "string" ? t.context : "";
			if (!n) throw Error("term required");
			let a = {
				term: n,
				context: r
			};
			try {
				let t = await O(e, a), n = await o();
				return {
					ok: !0,
					wordId: t.wordId,
					inboxCount: n
				};
			} catch (e) {
				throw N(e) && (await i(), j()), e;
			}
		}
		default: throw Error(`unknown action: ${t.action}`);
	}
}
function F(e) {
	let t = /* @__PURE__ */ new Set();
	try {
		let n = new URL(e);
		if (t.add(n.origin), n.hostname.endsWith(".web.app")) {
			let e = n.hostname.replace(/\.web\.app$/, ".firebaseapp.com");
			t.add(`${n.protocol}//${e}`);
		} else if (n.hostname.endsWith(".firebaseapp.com")) {
			let e = n.hostname.replace(/\.firebaseapp\.com$/, ".web.app");
			t.add(`${n.protocol}//${e}`);
		}
	} catch {}
	return t;
}
var I = F(e.frontendBaseUrl);
function L(e) {
	let t = e.origin ?? (e.url ? new URL(e.url).origin : void 0);
	return !!t && I.has(t);
}
function R() {
	chrome.runtime.onMessageExternal.addListener((t, n, i) => {
		if (!L(n)) return i({
			ok: !1,
			error: "unauthorized origin"
		}), !1;
		if (t?.type !== "lingogram-extension-auth") return i({
			ok: !1,
			error: "unknown message type"
		}), !1;
		let a = t.payload ?? {}, o = typeof a.customToken == "string" ? a.customToken : "", s = typeof a.email == "string" ? a.email : "", c = typeof a.uid == "string" ? a.uid : "", l = typeof a.nonce == "string" ? a.nonce : "";
		return !o || !c ? (i({
			ok: !1,
			error: "customToken and uid required"
		}), !1) : ((async () => {
			if (!await u(l)) {
				i({
					ok: !1,
					error: "invalid or expired auth challenge — open the extension popup and start the sign-in flow from there"
				});
				return;
			}
			try {
				let t = await m(e, o, c);
				await r({
					idToken: t.idToken,
					refreshToken: t.refreshToken,
					expiresAt: t.expiresAt,
					email: s,
					uid: t.uid
				}), await d(), M(), i({ ok: !0 });
			} catch (e) {
				i({
					ok: !1,
					error: String(e instanceof Error ? e.message : e)
				});
			}
		})(), !0);
	});
}
function z() {
	chrome.runtime.onMessage.addListener((e, t, n) => A(e?.action) ? ((async () => {
		try {
			n(await P(e));
		} catch (e) {
			console.error("Background auth handler error:", e), n({
				ok: !1,
				error: String(e instanceof Error ? e.message : e)
			});
		}
	})(), !0) : !1);
}
async function B() {
	let e = await n();
	e && !e.refreshToken && (await i(), j());
}
function V() {
	z(), R(), B();
}
//#endregion
//#region src/background/background.ts
async function H(e, t = 3, n = 1e3) {
	for (let r = 0; r < t; r++) try {
		let t = await fetch(e);
		if (!t.ok) throw Error(`HTTP error! status: ${t.status}`);
		return await t.text();
	} catch (i) {
		if (console.warn(`Fetch attempt ${r + 1} failed for ${e}:`, i.message), r < t - 1) await new Promise((e) => setTimeout(e, n));
		else throw i;
	}
	throw Error(`Failed to fetch ${e} after ${t} attempts`);
}
V(), chrome.runtime.onMessage.addListener((e, t) => e.action === "TIME_UPDATE" || e.action === "SEEK_VIDEO" || e.action === "VTT_LOADED" ? (t.tab && t.tab.id && chrome.tabs.sendMessage(t.tab.id, e), !1) : (e.action === "FETCH_VTT" && H(e.url).then((n) => {
	t.tab && t.tab.id && chrome.tabs.sendMessage(t.tab.id, {
		action: "VTT_LOADED",
		payload: n,
		url: e.url
	});
}).catch((e) => {
	console.error("Background: Failed to fetch VTT:", e);
}), !1));
//#endregion
export { H as fetchWithRetry };
